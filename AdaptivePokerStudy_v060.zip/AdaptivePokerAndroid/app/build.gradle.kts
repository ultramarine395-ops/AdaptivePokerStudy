plugins {
    id("com.android.application")
}

android {
    namespace = "com.adaptivepoker.study"
    compileSdk = 37

    defaultConfig {
        applicationId = "com.adaptivepoker.study"
        minSdk = 26
        targetSdk = 35
        versionCode = 6
        versionName = "0.6.0"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
