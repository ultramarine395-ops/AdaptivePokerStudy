/* Adaptive Poker Study 0.6.0 — local post-session review only. */
'use strict';

const DB_NAME = 'adaptive-poker-study';
const DB_STORE = 'kv';
const RANGE_FILES = ['MTT_5_GTO.json','MTT_10_GTO.json','MTT_20_GTO.json','MTT_40_GTO.json','MTT_100_GTO.json'];
const STACK_BUCKETS = [5,10,20,40,100];
const state = {hands:[], decisions:[], ranges:{}, solverLibrary:{schema_version:1,nodes:[]}, solverTrees:[], sessions:[], currentDecision:null};
let dbPromise = null;
let toastTimer = null;
let currentQuiz=null;let quizAttempts=0;let quizInMix=0;

function openDb(){
  if (!('indexedDB' in window)) return Promise.resolve(null);
  if (dbPromise) return dbPromise;
  dbPromise = new Promise(resolve=>{
    const req = indexedDB.open(DB_NAME,1);
    req.onupgradeneeded=()=>{ const db=req.result; if(!db.objectStoreNames.contains(DB_STORE)) db.createObjectStore(DB_STORE,{keyPath:'key'}); };
    req.onsuccess=()=>resolve(req.result);
    req.onerror=()=>resolve(null);
  });
  return dbPromise;
}
async function dbGet(key){
  const db=await openDb();
  if(!db){ try{return JSON.parse(localStorage.getItem('aps_'+key)||'null');}catch(e){return null;} }
  return new Promise(resolve=>{const tx=db.transaction(DB_STORE,'readonly');const r=tx.objectStore(DB_STORE).get(key);r.onsuccess=()=>resolve(r.result?.value??null);r.onerror=()=>resolve(null);});
}
async function dbSet(key,value){
  const db=await openDb();
  if(!db){localStorage.setItem('aps_'+key,JSON.stringify(value));return;}
  return new Promise((resolve,reject)=>{const tx=db.transaction(DB_STORE,'readwrite');tx.objectStore(DB_STORE).put({key,value});tx.oncomplete=()=>resolve();tx.onerror=()=>reject(tx.error);});
}
async function saveState(){
  try{await Promise.all([
    dbSet('hands',state.hands),dbSet('decisions',state.decisions),dbSet('ranges',state.ranges),
    dbSet('solverLibrary',state.solverLibrary),dbSet('solverTrees',state.solverTrees),dbSet('sessions',state.sessions)
  ]);}catch(e){showToast('Не удалось сохранить базу: '+e.message);}
}
async function loadState(){
  state.hands=await dbGet('hands')||[];
  state.decisions=await dbGet('decisions')||[];
  state.ranges=await dbGet('ranges')||{};
  state.solverLibrary=await dbGet('solverLibrary')||{schema_version:1,nodes:[]};
  state.solverTrees=await dbGet('solverTrees')||[];
  state.sessions=await dbGet('sessions')||[];
  renderAll();
}
function showToast(msg){
  const el=document.getElementById('toast'); if(!el)return; el.textContent=msg;el.classList.add('show');
  clearTimeout(toastTimer);toastTimer=setTimeout(()=>el.classList.remove('show'),2600);
}
function escapeHtml(v){return String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function fmt(v,d=1){return (v===null||v===undefined||v==='')?'—':Number(v).toFixed(d);}
function pythonRound(x,ndigits=0){
  const value=Number(x);if(!Number.isFinite(value))return value;if(value===0)return 0;
  const buf=new ArrayBuffer(8),view=new DataView(buf);view.setFloat64(0,Math.abs(value),false);const bits=view.getBigUint64(0,false);
  const exp=Number((bits>>52n)&2047n),frac=bits&((1n<<52n)-1n);const mant=exp===0?frac:((1n<<52n)|frac);const e2=exp===0?-1074:exp-1023-52;
  const scale=10n**BigInt(Math.max(0,ndigits));let numerator=mant*scale,denominator=1n;
  if(e2>=0)numerator<<=BigInt(e2);else denominator<<=BigInt(-e2);
  let q=numerator/denominator;const rem=numerator%denominator;const twice=rem*2n;
  if(twice>denominator||(twice===denominator&&(q&1n)===1n))q++;
  const rounded=Number(q)/Math.pow(10,Math.max(0,ndigits));return value<0?-rounded:rounded;
}
function round2(x){return pythonRound(Number(x),2);}
function roundHalf(x){return pythonRound(Number(x)*2,0)/2;}
function fixed2(x){return pythonRound(Number(x),2).toFixed(2);}
function cardClass(cards){
  if(!Array.isArray(cards)||cards.length!==2)return null;
  const valid=c=>/^[2-9TJQKA][shdc]$/i.test(String(c));
  if(!valid(cards[0])||!valid(cards[1]))return null;
  const ranks='23456789TJQKA';const a=String(cards[0]).charAt(0).toUpperCase(),b=String(cards[1]).charAt(0).toUpperCase();
  if(a===b)return a+b;
  const ordered=[a,b].sort((x,y)=>ranks.indexOf(y)-ranks.indexOf(x));
  const suited=String(cards[0]).charAt(1).toLowerCase()===String(cards[1]).charAt(1).toLowerCase();
  return ordered.join('')+(suited?'s':'o');
}
function parseAmountList(text){return (String(text).match(/[\d,]+/g)||[]).map(x=>parseInt(x.replace(/,/g,''),10)||0);}
function parseAction(line,street){
  const m=String(line).trim().match(/^([^:]+):\s+(.*)$/);if(!m)return null;
  const player=m[1].trim(),rest=m[2].trim(),low=rest.toLowerCase(),nums=parseAmountList(rest);
  const all_in=low.includes('is all-in')||low.includes('and is all-in');
  if(low.startsWith('posts the ante'))return {street,player,kind:'ante',amount:nums.length?nums[nums.length-1]:0,raw:rest};
  if(low.startsWith('posts small blind'))return {street,player,kind:'sb',amount:nums.length?nums[nums.length-1]:0,raw:rest};
  if(low.startsWith('posts big blind'))return {street,player,kind:'bb',amount:nums.length?nums[nums.length-1]:0,raw:rest};
  if(low.startsWith('folds'))return {street,player,kind:'fold',all_in,raw:rest};
  if(low.startsWith('checks'))return {street,player,kind:'check',all_in,raw:rest};
  if(low.startsWith('calls'))return {street,player,kind:'call',amount:nums.length?nums[0]:0,all_in,raw:rest};
  if(low.startsWith('bets'))return {street,player,kind:'bet',amount:nums.length?nums[0]:0,all_in,raw:rest};
  if(low.startsWith('raises'))return {street,player,kind:'raise',amount:nums.length?nums[0]:0,amount_to:nums.length>1?nums[1]:null,all_in,raw:rest};
  if(low.startsWith('is all-in'))return {street,player,kind:'allin',amount:0,all_in:true,raw:rest};
  return null;
}
function parseHandBlock(block){
  const lines=String(block).trim().split(/\r?\n/);if(!lines.length||!lines[0].startsWith('Poker Hand #'))return null;
  const header=lines[0];
  const id=(header.match(/Poker Hand #([^:]+)/)||[])[1]||'';
  const tour=header.match(/Tournament #(\d+), (.*?) Hold'em No Limit/);
  const time=(header.match(/ - (\d{4}\/\d\d\/\d\d \d\d:\d\d:\d\d)/)||[])[1]||null;
  const level=header.match(/- Level([^ (]+)\(([^/]+)\/([^()]+)(?:\(([^()]+)\))?\)/);
  const table=String(block).match(/Table '([^']+)' (\d+)-max Seat #(\d+) is the button/);
  const h={hand_id:id,tournament_id:tour?tour[1]:null,tournament_name:tour?tour[2].trim():null,
    timestamp:time,level:level?level[1]:null,small_blind:level?parseAmountList(level[2])[0]||0:0,
    big_blind:level?parseAmountList(level[3])[0]||0:0,ante:level&&level[4]?parseAmountList(level[4])[0]||0:0,
    table:table?table[1]:null,table_size:table?parseInt(table[2],10):0,button_seat:table?parseInt(table[3],10):null,
    players:[],hero_cards:null,boards:{flop:[],turn:[],river:[]},actions:[],game_type:(tour&&tour[2].toLowerCase().includes('bounty'))?'PKO':'tournament_chipEV'};
  const seatText=String(block).split('*** HOLE CARDS ***')[0];
  const seatRe=/^Seat (\d+): (.*?) \(([\d,]+) in chips\)/gm;let sm;
  while((sm=seatRe.exec(seatText))!==null)h.players.push({seat:parseInt(sm[1],10),name:sm[2].trim(),starting_stack:parseAmountList(sm[3])[0]||0});
  let street='preflop',inHole=false;
  for(const rawLine of lines){
    const line=rawLine.trim();
    if(line.startsWith('*** HOLE CARDS ***')){street='preflop';inHole=true;continue;}
    if(line.startsWith('*** FLOP ***')){street='flop';inHole=true;const c=line.match(/\[([^\]]+)\]/);if(c)h.boards.flop=c[1].split(/\s+/);continue;}
    if(line.startsWith('*** TURN ***')){street='turn';const cs=[...line.matchAll(/\[([^\]]+)\]/g)];if(cs.length)h.boards.turn=cs[cs.length-1][1].split(/\s+/);continue;}
    if(line.startsWith('*** RIVER ***')){street='river';const cs=[...line.matchAll(/\[([^\]]+)\]/g)];if(cs.length)h.boards.river=cs[cs.length-1][1].split(/\s+/);continue;}
    if(line.startsWith('*** ')){inHole=false;continue;}
    if(line.startsWith('Dealt to ')){
      const dealt=line.match(/^Dealt to (.*?) \[([^\]]+)\]/);
      if(dealt)h.hero_cards=dealt[2].split(/\s+/);
      continue;
    }
    if(inHole){const a=parseAction(line,street);if(a)h.actions.push(a);}
    else if(line.includes(': posts ')){const a=parseAction(line,'preflop');if(a)h.actions.push(a);}
  }
  return h;
}
function parseGGText(text){
  const hands=String(text).split(/(?=Poker Hand #)/).map(parseHandBlock).filter(Boolean);
  const decisions=[];for(const h of hands)decisions.push(...buildDecisions(h,'Hero'));
  return {hands,decisions};
}
function positionBySeat(hand,seat){
  if(!hand.button_seat||!hand.table_size)return 'unknown';
  const offset=(seat-hand.button_seat+hand.table_size)%hand.table_size;
  const labels={2:['BTN','BB'],3:['BTN','SB','BB'],4:['BTN','SB','BB','CO'],5:['BTN','SB','BB','UTG','CO'],
    6:['BTN','SB','BB','UTG','HJ','CO'],7:['BTN','SB','BB','UTG','MP','HJ','CO'],
    8:['BTN','SB','BB','UTG','UTG1','MP','HJ','CO'],9:['BTN','SB','BB','UTG','UTG1','MP','HJ','CO','LJ']};
  const row=labels[hand.table_size]||(hand.table_size>=8?labels[8]:labels[6]);return row[offset]||'unknown';
}
function solverActionLabel(a,potBefore,facing){
  if(a.street==='preflop')return null;
  if(['check','fold','call'].includes(a.kind))return a.kind;
  if(a.kind==='allin'||(a.all_in&&['bet','raise'].includes(a.kind)))return 'jam';
  if(a.kind==='bet'){const size=potBefore>0?a.amount/potBefore*100:0;return size>0?'bet_'+Math.round(size):null;}
  if(a.kind==='raise'){const den=potBefore+facing;const size=den>0?a.amount/den*100:0;return size>0?'raise_'+Math.round(size):null;}
  return null;
}
function tokenFor(a,pos,bb,streetContrib){
  if(a.kind==='raise'){const to=a.amount_to!==null&&a.amount_to!==undefined?a.amount_to:(streetContrib[a.player]||0)+a.amount;return `${pos}:raise_to_${fixed2(to/bb)}bb`;}
  if(a.kind==='bet'){const to=streetContrib[a.player]||0;return `${pos}:bet_to_${fixed2(to/bb)}bb`;}
  return `${pos}:${a.kind}`;
}
function stableCanonicalContext(ctx){
  const floatKeys=new Set(['small_blind_bb','ante_bb','effective_stack_bb','pot_before_bb','facing_bet_bb','preflop_villain_stack_bb']);
  function val(v,key){
    if(v===null||v===undefined)return 'null';
    if(Array.isArray(v))return '['+v.map(x=>val(x,'')).join(',')+']';
    if(typeof v==='object')return '{'+Object.keys(v).sort().map(k=>JSON.stringify(k)+':'+val(v[k],k)).join(',')+'}';
    if(typeof v==='string')return JSON.stringify(v);
    if(typeof v==='number')return floatKeys.has(key)&&Number.isInteger(v)?v.toFixed(1):String(v);
    return JSON.stringify(v);
  }
  return '{'+Object.keys(ctx).sort().map(k=>JSON.stringify(k)+':'+val(ctx[k],k)).join(',')+'}';
}
function sha256(ascii){
  const math=Math,words=[],K=[];let isPrime=n=>{for(let j=2;j*j<=n;j++)if(n%j===0)return false;return true;};
  for(let n=2,c=0;c<64;n++)if(isPrime(n)){if(c<8)words[c]=math.floor((math.sqrt(n)%1)*4294967296);K[c]=math.floor((math.pow(n,1/3)%1)*4294967296);c++;}
  const msg=unescape(encodeURIComponent(ascii));const bitLen=msg.length*8;const data=msg+'\x80'+Array((56-(msg.length+1)%64+64)%64).fill('\x00').join('')+String.fromCharCode(0,0,0,0,(bitLen>>>24)&255,(bitLen>>>16)&255,(bitLen>>>8)&255,bitLen&255);
  let H=words.slice(0,8);const right=(x,n)=>(x>>>n)|(x<<(32-n));
  for(let i=0;i<data.length;i+=64){const w=new Array(64);for(let j=0;j<16;j++)w[j]=((data.charCodeAt(i+j*4)&255)<<24)|((data.charCodeAt(i+j*4+1)&255)<<16)|((data.charCodeAt(i+j*4+2)&255)<<8)|(data.charCodeAt(i+j*4+3)&255);
    for(let j=16;j<64;j++){const a=w[j-15],b=w[j-2],s0=right(a,7)^right(a,18)^(a>>>3),s1=right(b,17)^right(b,19)^(b>>>10);w[j]=(w[j-16]+s0+w[j-7]+s1)|0;}
    let [a,b,c,d,e,f,g,h]=H;
    for(let j=0;j<64;j++){const S1=right(e,6)^right(e,11)^right(e,25),ch=(e&f)^(~e&g),t1=(h+S1+ch+K[j]+w[j])|0;const S0=right(a,2)^right(a,13)^right(a,22),maj=(a&b)^(a&c)^(b&c),t2=(S0+maj)|0;h=g;g=f;f=e;e=(d+t1)|0;d=c;c=b;b=a;a=(t1+t2)|0;}
    H=H.map((x,j)=>(x+[a,b,c,d,e,f,g,h][j])|0);
  }
  return H.map(x=>(x>>>0).toString(16).padStart(8,'0')).join('');
}
function buildDecisions(hand,hero='Hero'){
  if(!hand.big_blind||!hand.players.some(p=>p.name===hero))return [];
  const seatFor={};hand.players.forEach(p=>seatFor[p.name]=p.seat);
  const playerByName={};hand.players.forEach(p=>playerByName[p.name]=p);
  const total={},street={},folded=new Set(),history=[],spots=[];let currentStreet='preflop';
  for(const a of hand.actions){
    if(a.street!==currentStreet){for(const k of Object.keys(street))delete street[k];currentStreet=a.street;}
    total[a.player]=total[a.player]||0;street[a.player]=street[a.player]||0;
    if(['ante','sb','bb'].includes(a.kind)){total[a.player]+=a.amount;if(a.kind==='sb'||a.kind==='bb')street[a.player]+=a.amount;continue;}
    if(a.player===hero&&['fold','check','call','bet','raise','allin'].includes(a.kind)){
      const heroSeat=seatFor[hero],pos=positionBySeat(hand,heroSeat);let live=[];
      for(const p of hand.players){if(p.name===hero||folded.has(p.name))continue;live.push(Math.max(0,p.starting_stack-(total[p.name]||0)));}
      const heroRemaining=Math.max(0,playerByName[hero].starting_stack-(total[hero]||0));
      const effective=Math.min(heroRemaining,live.length?Math.max(...live):heroRemaining);
      const maxStreet=Math.max(0,...Object.values(street));const facing=Math.max(0,maxStreet-(street[hero]||0));
      const pot=Object.values(total).reduce((a,b)=>a+b,0);const solverLabel=solverActionLabel(a,pot,facing);
      let villainStack=null;
      if(a.street==='preflop'){
        const raises=[];for(const token of history){if(!token.includes(':'))continue;const [p,act]=token.split(':',2);if(act.startsWith('raise_to_')||act==='jam'||act==='allin')raises.push(p);}
        if(raises.length){const last=raises[raises.length-1];const villain=hand.players.find(p=>positionBySeat(hand,p.seat)===last);if(villain){const remaining=Math.max(0,villain.starting_stack-(total[villain.name]||0));villainStack=roundHalf(Math.min(heroRemaining,remaining)/hand.big_blind);}}
      }
      let label;
      if(a.all_in&&a.kind==='call')label='call_allin';
      else if(a.kind==='allin'||(a.all_in&&['raise','bet'].includes(a.kind)))label='jam';
      else if(a.kind==='raise'){const to=a.amount_to!==null&&a.amount_to!==undefined?a.amount_to:(street[hero]||0)+a.amount;label='raise_to_'+(to/hand.big_blind).toFixed(2)+'bb';}
      else if(a.kind==='bet'){const to=(street[hero]||0)+a.amount;label='bet_to_'+(to/hand.big_blind).toFixed(2)+'bb';}
      else label=a.kind;
      let board=[];if(a.street==='flop')board=hand.boards.flop||[];if(a.street==='turn')board=[...(hand.boards.flop||[]),...(hand.boards.turn||[])];if(a.street==='river')board=[...(hand.boards.flop||[]),...(hand.boards.turn||[]),...(hand.boards.river||[])];
      const cardsText=hand.hero_cards?hand.hero_cards.join(' '):null;const hclass=cardClass(hand.hero_cards);
      const ctx={game_type:hand.game_type,table_size:hand.table_size,players_dealt:hand.players.length,
        small_blind_bb:round2(hand.small_blind/hand.big_blind),ante_bb:round2(hand.ante/hand.big_blind),street:a.street,position:pos,
        effective_stack_bb:roundHalf(effective/hand.big_blind),pot_before_bb:round2(pot/hand.big_blind),facing_bet_bb:round2(facing/hand.big_blind),
        hand:a.street==='preflop'?hclass:cardsText,board,action_history:history.slice(),solver_action_label:solverLabel,preflop_villain_stack_bb:villainStack};
      const key=sha256(stableCanonicalContext(ctx));
      spots.push({hand_id:hand.hand_id,tournament_id:hand.tournament_id,game_type:hand.game_type,table_size:hand.table_size,players_dealt:hand.players.length,
        small_blind_bb:ctx.small_blind_bb,ante_bb:ctx.ante_bb,street:a.street,position:pos,hole_cards:cardsText,hand_class:hclass,board:board.join(' '),
        effective_stack_bb:ctx.effective_stack_bb,pot_before_bb:ctx.pot_before_bb,facing_bet_bb:ctx.facing_bet_bb,action_history:history.slice(),
        action_taken:label,spot_key:key,spot_context:ctx,solver_action_label:solverLabel,preflop_villain_stack_bb:villainStack,
        tournament_name:hand.tournament_name,timestamp:hand.timestamp});
    }
    if(a.kind==='fold')folded.add(a.player);
    else if(['call','bet','raise','allin'].includes(a.kind)){
      if(a.kind==='raise'&&a.amount_to!==null&&a.amount_to!==undefined){const delta=Math.max(0,a.amount_to-(street[a.player]||0));total[a.player]+=delta;street[a.player]=a.amount_to;}
      else{total[a.player]+=a.amount;street[a.player]=(street[a.player]||0)+a.amount;}
    }
    const p=playerByName[a.player];const pos=p?positionBySeat(hand,p.seat):'?';history.push(tokenFor(a,pos,hand.big_blind,street));
  }
  return spots;
}

function positionKey(tableSize,pos){
  if(tableSize===6){if(['LJ','HJ','CO','BTN','SB','BB'].includes(pos))return pos;return ({UTG:'LJ'}[pos]||null);}
  if(tableSize===8){if(['EP2','EP3','LJ','HJ','CO','BTN','SB','BB'].includes(pos))return pos;return ({UTG:'EP2',UTG1:'EP3',MP:'LJ'}[pos]||(['HJ','CO','BTN','SB','BB'].includes(pos)?pos:null));}
  if(tableSize===9){if(['EP1','EP2','EP3','LJ','HJ','CO','BTN','SB','BB'].includes(pos))return pos;return ({UTG:'EP1',UTG1:'EP2',MP:'EP3'}[pos]||(['HJ','CO','BTN','SB','BB','LJ'].includes(pos)?pos:null));}
  return null;
}
function classifyScenario(position,tableSize,history){
  const hero=positionKey(tableSize,position);if(!hero)return null;
  const raises=[];let invalid=false;
  for(const tok of history){if(!tok.includes(':')){invalid=true;continue;}const [pos,act]=tok.split(':',2);const a=act.toLowerCase();
    if(a.startsWith('raise_to_')||a==='jam'||a==='allin')raises.push([pos,a]);
    else if(a==='fold')continue;
    else if(a==='call'||a==='call_allin')invalid=true;
    else invalid=true;
  }
  if(invalid)return null;
  if(raises.length===0)return {type:'open',hero,villain:null,raise:`Open${hero}`,call:`Limp${hero}`};
  if(raises.length===1){const villain=positionKey(tableSize,raises[0][0]);if(!villain||villain===hero)return null;return {type:'vs_open',hero,villain,raise:`3Bet${hero}vs${villain}`,call:`Call${hero}vs${villain}`};}
  if(raises.length===2&&raises[0][0]===position&&raises[1][0]!==position){const villain=positionKey(tableSize,raises[1][0]);if(!villain)return null;return {type:'vs_3bet',hero,villain,raise:`4Bet${hero}vs${villain}`,call:`Call 3Bet${hero}vs${villain}`};}
  if(raises.length===3&&raises[1][0]===position&&raises[0][0]!==position&&raises[2][0]!==position){const villain=positionKey(tableSize,raises[2][0]);if(!villain)return null;return {type:'vs_4bet',hero,villain,raise:`5Bet${hero}vs${villain}`,call:`Call 4Bet${hero}vs${villain}`};}
  if(raises.length===4&&raises[0][0]===position&&raises[2][0]===position&&raises[1][0]!==position&&raises[3][0]!==position){const villain=positionKey(tableSize,raises[3][0]);if(!villain)return null;return {type:'vs_5bet',hero,villain,raise:null,call:`Call 5Bet${hero}vs${villain}`};}
  return null;
}
function evaluatePreflop(spot){
  const base={status:'unmatched',frequency:null,mix:{},note:'Нет точного сопоставления.'};
  if(spot.street!=='preflop')return {...base,status:'not_preflop'};
  if(!spot.hand_class)return {...base,note:'Не удалось распознать карты Hero.'};
  const scenario=classifyScenario(spot.position,spot.table_size,spot.action_history||[]);
  if(!scenario)return {...base,note:'Лимп, колл до Hero, squeeze или другая неподдерживаемая линия. Не угадываем чарт.'};
  if(scenario.type==='open'&&spot.position==='BB'&&spot.action_taken==='check')return {status:'forced_check',frequency:1,mix:{check:1},note:'Вынужденный check в закрытом BB, не добровольное решение.'};
  let refStack=spot.effective_stack_bb;
  if(scenario.type!=='open'&&spot.preflop_villain_stack_bb!==null&&spot.preflop_villain_stack_bb!==undefined)refStack=spot.preflop_villain_stack_bb;
  const bucket=STACK_BUCKETS.reduce((best,n)=>Math.abs(n-refStack)<Math.abs(best-refStack)?n:best,STACK_BUCKETS[0]);
  const rel=bucket?Math.abs(refStack-bucket)/bucket:1;const fit=rel<=.25?'close':rel<=.5?'approximate':'weak';
  const data=state.ranges[bucket];if(!data)return {...base,status:'ranges_missing',note:`Нет загруженного профиля ${bucket} BB.`};
  const keys=[scenario.raise,scenario.call].filter(Boolean);if(keys.some(k=>!Object.prototype.hasOwnProperty.call(data,k)))return {...base,status:'scenario_missing',note:'В загруженном наборе нет именно этого сценария.'};
  const raise=scenario.raise?Number(data[scenario.raise][spot.hand_class]||0):0;
  const call=scenario.call?Number(data[scenario.call][spot.hand_class]||0):0;
  let fold=1-raise-call;if(fold<-.02)return {...base,note:'Частоты источника превышают 100%; данные не нормализованы.'};fold=Math.max(0,fold);
  const mix={raise,fold};if(scenario.type==='open')mix.limp=call;else mix.call=call;
  let observed=spot.action_taken;
  if(observed.startsWith('raise_to_')||observed==='jam')observed='raise';
  if(observed==='call_allin')observed='call';
  if(observed==='call'&&scenario.type==='open')observed='limp';
  if(!Object.prototype.hasOwnProperty.call(mix,observed))return {...base,note:'Действие не сопоставлено с категориями этого сценария.'};
  const note=`${bucket} BB chart; отклонение глубины ${(rel*100).toFixed(1)}%. Generic MTT chip-EV, не PKO/ICM. Сайзинг может отличаться от источника.`;
  return {status:'matched',frequency:mix[observed],mix,observed,bucket,fit,note,scenario:`${scenario.type}: ${scenario.raise||scenario.call}`};
}
function evaluateSolver(spot){
  const node=(state.solverLibrary.nodes||[]).find(n=>n.key===spot.spot_key);
  if(!node)return {status:'no_reference'};
  const strategy=node.strategy||{};const key=spot.solver_action_label||spot.action_taken;
  const legacy=spot.action_taken;const match=Object.prototype.hasOwnProperty.call(strategy,key)?key:(Object.prototype.hasOwnProperty.call(strategy,legacy)?legacy:null);
  const result={status:'matched',source:node.source||'Imported TexasSolver library',mix:strategy,actionLabel:match,frequency:match?Number(strategy[match]):null};
  const evs=node.action_ev_bb||{};
  if(Object.keys(evs).length&&Object.prototype.hasOwnProperty.call(evs,spot.action_taken))result.evLoss=Math.max(0,...Object.values(evs).map(Number))-Number(evs[spot.action_taken]);
  return result;
}

function getDecisionAnalysis(spot){return spot.street==='preflop'?evaluatePreflop(spot):evaluateSolver(spot);}
function renderAll(){renderDashboard();renderDecisionList();renderLibrary();}
function renderDashboard(){
  const pre=state.decisions.filter(d=>d.street==='preflop');const post=state.decisions.filter(d=>d.street!=='preflop');
  const matched=pre.map(evaluatePreflop).filter(x=>x.status==='matched').length;const postMatched=post.map(evaluateSolver).filter(x=>x.status==='matched').length;
  document.getElementById('stat-hands').textContent=state.hands.length.toLocaleString('ru-RU');
  document.getElementById('stat-decisions').textContent=state.decisions.length.toLocaleString('ru-RU');
  document.getElementById('stat-preflop').textContent=state.ranges&&Object.keys(state.ranges).length?`${matched}/${pre.length}`:'—';
  document.getElementById('stat-postflop').textContent=(state.solverLibrary.nodes||[]).length?`${postMatched}/${post.length}`:'—';
  document.getElementById('session-count').textContent=`${state.sessions.length} ${plural(state.sessions.length,'сессия','сессии','сессий')}`;
  const box=document.getElementById('recent-sessions');
  if(!state.sessions.length){box.className='session-list empty-state';box.innerHTML='<div class="empty-symbol">♧</div><b>Пока нет историй</b><span>Импортируй TXT или ZIP с Hand History — приложение обработает их локально.</span>';return;}
  box.className='session-list';box.innerHTML=state.sessions.slice(-5).reverse().map(s=>`<div class="session-item"><div><b>${escapeHtml(s.name)}</b><small>${escapeHtml(s.date)} · ${s.hands} раздач · ${s.decisions} решений</small></div><span class="session-count">+${s.decisions}</span></div>`).join('');
}
function plural(n,a,b,c){n=Math.abs(n)%100;const n1=n%10;if(n>10&&n<20)return c;if(n1>1&&n1<5)return b;if(n1===1)return a;return c;}
function renderDecisionList(){
  const root=document.getElementById('decision-list');if(!root)return;
  const term=(document.getElementById('hand-search')?.value||'').toLowerCase();const street=document.getElementById('street-filter')?.value||'all';
  let list=state.decisions.filter(d=>(street==='all'||d.street===street)&&(!term||[d.hand_class,d.hole_cards,d.position,d.board,d.action_taken,d.hand_id].join(' ').toLowerCase().includes(term)));
  document.getElementById('decision-list-summary').textContent=`${list.length} из ${state.decisions.length} решений`;
  if(!list.length){root.className='decision-list empty-state';root.innerHTML='<b>Нет подходящих решений</b><span>Импортируй историю или измени фильтр.</span>';return;}
  root.className='decision-list';root.innerHTML=list.slice().reverse().slice(0,500).map((d,i)=>{
    const streetName={preflop:'ПРЕФЛОП',flop:'ФЛОП',turn:'ТЁРН',river:'РИВЕР'}[d.street]||d.street.toUpperCase();
    const hand=d.street==='preflop'?(d.hand_class||'??'):(d.hole_cards||'карты не распознаны');
    const stack=`${fmt(d.effective_stack_bb,1)} BB`;const meta=`${d.position||'?'} · ${stack} · банк ${fmt(d.pot_before_bb,1)} BB`;
    const analysis=getDecisionAnalysis(d);let badge='';
    if(analysis.status==='matched'&&analysis.frequency!==null)badge=`<span class="count-chip">${Math.round(analysis.frequency*100)}% mix</span>`;
    return `<div class="decision-item" onclick="openDecision(${state.decisions.indexOf(d)})"><div class="decision-top"><span class="decision-hand">${escapeHtml(hand)}</span><span class="street-pill ${d.street==='preflop'?'':'post'}">${streetName}</span></div><div class="decision-meta">${escapeHtml(meta)}</div><div class="decision-top"><div class="decision-action">Действие: <b>${escapeHtml(d.action_taken)}</b></div>${badge}</div></div>`;
  }).join('');
}
function renderLibrary(){
  const cnt=Object.keys(state.ranges||{}).length;document.getElementById('range-status').textContent=cnt?`Загружено профилей: ${cnt}/5`:'Диапазоны не загружены';document.getElementById('range-dot').classList.toggle('ready',cnt===5);
  const nodes=(state.solverLibrary.nodes||[]).length;document.getElementById('solver-status').textContent=nodes?`Импортировано узлов: ${nodes}`:'Нет импортированных узлов';document.getElementById('solver-dot').classList.toggle('ready',nodes>0);
  const trees=state.solverTrees.length;document.getElementById('solver-tree-status').textContent=trees?`Импортировано деревьев: ${trees}`:'Нет импортированных деревьев';document.getElementById('solver-tree-dot').classList.toggle('ready',trees>0);
}
function switchPage(page,button){document.querySelectorAll('.page').forEach(p=>p.classList.toggle('active',p.id===page));document.querySelectorAll('.nav-item').forEach(b=>b.classList.toggle('active',b===button));if(page==='hands')renderDecisionList();}
function pickImport(){if(window.AndroidBridge&&AndroidBridge.pickFile){AndroidBridge.pickFile();return;}const input=document.createElement('input');input.type='file';input.accept='.txt,.zip,.json,.csv';input.onchange=()=>{const f=input.files[0];if(!f)return;const r=new FileReader();r.onload=()=>onFallbackFile(f.name,r.result);r.readAsText(f);};input.click();}
function decodeBase64Utf8(b64){const bin=atob(b64);const bytes=new Uint8Array(bin.length);for(let i=0;i<bin.length;i++)bytes[i]=bin.charCodeAt(i);return new TextDecoder('utf-8',{fatal:false}).decode(bytes);}
async function importEntries(sourceName,entries){
  let addedHands=0,addedDecisions=0,rangeAdded=0,solverAdded=0,other=0;
  const existingHand=new Set(state.hands.map(h=>h.hand_id));const existingDecision=new Set(state.decisions.map(d=>d.spot_key));
  let rawText=[];let decisionsCandidates=[];
  for(const entry of entries){
    const name=entry.name||sourceName;const lower=name.toLowerCase();let txt;
    try{txt=decodeBase64Utf8(entry.base64||'');}catch(e){continue;}
    if(lower.endsWith('.txt'))rawText.push({name,text:txt});
    else if(lower.endsWith('.json')){
      let obj;try{obj=JSON.parse(txt);}catch(e){showToast(`JSON inválиден: ${name}`);continue;}
      if(Array.isArray(obj)&&obj.length&&obj[0].spot_key){decisionsCandidates.push({name,rows:obj});continue;}
      if(obj&&obj.schema_version===1&&Array.isArray(obj.nodes)){
        const map=new Map((state.solverLibrary.nodes||[]).map(n=>[n.key,n]));obj.nodes.forEach(n=>{if(n&&n.key&&n.strategy){map.set(n.key,n);solverAdded++;}});state.solverLibrary={schema_version:1,nodes:[...map.values()]};continue;
      }
      if(obj&&obj.schema_version===1&&Array.isArray(obj.hands)&&Array.isArray(obj.decisions)){
        const hm=new Set(state.hands.map(h=>h.hand_id));obj.hands.forEach(h=>{if(h&&h.hand_id&&!hm.has(h.hand_id)){state.hands.push(h);hm.add(h.hand_id);addedHands++;}});
        const dm=new Set(state.decisions.map(d=>d.spot_key));obj.decisions.forEach(d=>{if(d&&d.spot_key&&!dm.has(d.spot_key)){state.decisions.push(d);dm.add(d.spot_key);addedDecisions++;}});
        if(obj.ranges)state.ranges={...state.ranges,...obj.ranges};
        if(obj.solver_library&&Array.isArray(obj.solver_library.nodes)){const nm=new Map(state.solverLibrary.nodes.map(n=>[n.key,n]));obj.solver_library.nodes.forEach(n=>nm.set(n.key,n));state.solverLibrary={schema_version:1,nodes:[...nm.values()]};}
        if(Array.isArray(obj.solver_trees)){state.solverTrees.push(...obj.solver_trees);solverAdded+=obj.solver_trees.length;}
        if(obj.ranges&&typeof obj.ranges==='object')rangeAdded+=Object.keys(obj.ranges).length;
        continue;
      }
      if(obj&&typeof obj.node_type==='string'&&(obj.childrens||obj.strategy)){
        state.solverTrees.push({name,tree:obj});solverAdded++;continue;
      }
      const match=name.match(/MTT_(5|10|20|40|100)_GTO\.json/i);
      if(match&&obj&&typeof obj==='object'&&!Array.isArray(obj)){state.ranges[match[1]]=obj;rangeAdded++;continue;}
      if(obj&&obj.files&&typeof obj.files==='object'){other++;continue;}
      showToast(`Незнакомый JSON-формат: ${name}`);
    } else if(lower.endsWith('.csv')){other++;}
  }
  // Prefer a complete all_decisions export when a ZIP contains both all_decisions and street subsets.
  if(decisionsCandidates.length){decisionsCandidates.sort((a,b)=>(b.name.toLowerCase().includes('all_decisions')?1:0)-(a.name.toLowerCase().includes('all_decisions')?1:0));const rows=decisionsCandidates[0].rows;
    for(const d of rows){if(d&&d.spot_key&&!existingDecision.has(d.spot_key)){state.decisions.push(d);existingDecision.add(d.spot_key);addedDecisions++;}}
    if(!rawText.length){const ids=new Set(state.hands.map(h=>h.hand_id));for(const d of rows){if(d.hand_id&&!ids.has(d.hand_id)){state.hands.push({hand_id:d.hand_id,tournament_id:d.tournament_id,tournament_name:d.tournament_name||'Imported decisions',game_type:d.game_type||'unknown',timestamp:d.timestamp||null,imported_from:sourceName});ids.add(d.hand_id);addedHands++;}}}
  }
  if(rawText.length){
    for(const entry of rawText){const parsed=parseGGText(entry.text);for(const h of parsed.hands){if(!existingHand.has(h.hand_id)){state.hands.push(h);existingHand.add(h.hand_id);addedHands++;}}
      for(const d of parsed.decisions){if(!existingDecision.has(d.spot_key)){state.decisions.push(d);existingDecision.add(d.spot_key);addedDecisions++;}}
    }
  }
  if(addedHands||addedDecisions||rangeAdded||solverAdded){
    if(addedHands||addedDecisions){const date=new Date().toLocaleString('ru-RU');state.sessions.push({name:sourceName,date,hands:addedHands,decisions:addedDecisions});}
    await saveState();renderAll();showToast(`Импорт: ${addedHands} рук · ${addedDecisions} решений`+(rangeAdded?` · ${rangeAdded} диапазонов`:'' )+(solverAdded?` · ${solverAdded} солверных данных`:''));
  }else if(other){await saveState();renderAll();showToast('Файл обработан, новых решений не найдено.');}
  else showToast('Новые данные не найдены или файл уже импортирован.');
}
function onNativeImport(name,entriesJson){try{const entries=JSON.parse(entriesJson);importEntries(name,entries);}catch(e){showToast('Ошибка импорта: '+e.message);}}
function onNativeImportError(message){showToast('Импорт: '+message);}
async function onFallbackFile(name,text){
  if(name.toLowerCase().endsWith('.txt')){const parsed=parseGGText(text);await importEntries(name,[{name,base64:btoa(unescape(encodeURIComponent(text)))}]);}
  else if(name.toLowerCase().endsWith('.json')){await importEntries(name,[{name,base64:btoa(unescape(encodeURIComponent(text)))}]);}
  else showToast('ZIP импорт доступен в Android-версии.');
}
function downloadRanges(){
  if(!window.AndroidBridge||!AndroidBridge.downloadRanges){showToast('Загрузка диапазонов доступна в Android-приложении.');return;}
  showToast('Загружаю пять открытых MTT-профилей…');AndroidBridge.downloadRanges();
}
async function onNativeRangesDownloaded(json){
  try{const files=JSON.parse(json);let n=0;for(const f of files){const text=decodeBase64Utf8(f.base64);const data=JSON.parse(text);const m=f.name.match(/MTT_(5|10|20|40|100)_GTO\.json/i);if(m&&data&&typeof data==='object'&&!Array.isArray(data)){state.ranges[m[1]]=data;n++;}}
    await saveState();renderAll();showToast(`Готово: загружено ${n} MTT-профилей.`);
  }catch(e){showToast('Не удалось обработать диапазоны: '+e.message);}
}
function onNativeRangeDownloadError(message){showToast('Загрузка: '+message);}
function onNativeExportSuccess(name){showToast('Сохранено: '+name);}
function onNativeExportError(message){showToast('Экспорт: '+message);}
function exportToDevice(name,mime,text){
  const bytes=new TextEncoder().encode(text);let binary='';for(let i=0;i<bytes.length;i++)binary+=String.fromCharCode(bytes[i]);const b64=btoa(binary);
  if(window.AndroidBridge&&AndroidBridge.exportFile){AndroidBridge.exportFile(name,mime,b64);return;}
  const blob=new Blob([text],{type:mime});const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=name;a.click();URL.revokeObjectURL(a.href);
}
function exportBackup(){const backup={schema_version:1,exported_at:new Date().toISOString(),hands:state.hands,decisions:state.decisions,ranges:state.ranges,solver_library:state.solverLibrary,solver_trees:state.solverTrees,sessions:state.sessions};exportToDevice('adaptive_poker_study_backup.json','application/json',JSON.stringify(backup,null,2));}
function exportCsv(){
  const fields=['hand_id','street','position','hole_cards','hand_class','board','effective_stack_bb','pot_before_bb','facing_bet_bb','action_taken','spot_key'];
  const rows=[fields.join(',')];for(const d of state.decisions){rows.push(fields.map(k=>csvCell(d[k])).join(','));}
  exportToDevice('adaptive_poker_decisions.csv','text/csv',rows.join('\r\n'));
}
function csvCell(v){let s=Array.isArray(v)?v.join(' '):String(v??'');return '"'+s.replace(/"/g,'""')+'"';}
async function clearDatabase(){
  if(!confirm('Удалить все локальные раздачи, диапазоны и солверные узлы?'))return;
  state.hands=[];state.decisions=[];state.ranges={};state.solverLibrary={schema_version:1,nodes:[]};state.solverTrees=[];state.sessions=[];
  await saveState();renderAll();showToast('Локальная база очищена.');
}
function openDecision(index){
  const d=state.decisions[index];if(!d)return;state.currentDecision=d;
  const a=getDecisionAnalysis(d);const isPre=d.street==='preflop';
  let analysisHtml='';
  if(isPre){
    if(a.status==='matched')analysisHtml=`<div class="gto-banner"><b>MTT chip-EV reference · ${a.bucket} BB</b><p>Выбранное действие встречается в ${Math.round(a.frequency*100)}% случаев для этой комбинации. Это частота, а не оценка потери EV.</p>${renderMix(a.mix)}</div>`;
    else if(a.status==='forced_check')analysisHtml=`<div class="gto-banner"><b>Вынужденный check</b><p>${escapeHtml(a.note)}</p></div>`;
    else analysisHtml=`<div class="gto-banner warn"><b>Нет точного префлоп-референса</b><p>${escapeHtml(a.note)}</p></div>`;
  } else {
    if(a.status==='matched')analysisHtml=`<div class="gto-banner"><b>Импортированная стратегия · TexasSolver</b><p>${a.frequency===null?'Действие не совпало с меткой солвера.':`Частота выбранного действия: ${Math.round(a.frequency*100)}%.`}</p>${renderMix(a.mix)}${a.evLoss!==undefined?`<p>EV loss: ${fmt(a.evLoss,3)} BB (только если EV для точного узла присутствует в библиотеке).</p>`:''}</div>`;
    else analysisHtml=`<div class="gto-banner warn"><b>Постфлоп-решение пока без эталона</b><p>Нет импортированной стратегии для полного совпадения этого spot_key. Приложение не подставляет похожий узел.</p></div>`;
  }
  const actions=(d.action_history||[]).map(x=>`<div class="action-line">${escapeHtml(x)}</div>`).join('')||'<div class="action-line">История до решения не распознана</div>';
  const title=isPre?(d.hole_cards||d.hand_class||'Префлоп'):(d.hole_cards||'Карты Hero');
  const html=`<div class="modal-backdrop" onclick="closeDecision(event)"><div class="modal" onclick="event.stopPropagation()"><div class="modal-handle"></div><div class="modal-head"><div><h2>${escapeHtml(title)}</h2><div class="modal-sub">${escapeHtml(d.hand_id||'')} · ${escapeHtml(d.street.toUpperCase())} · ${escapeHtml(d.position||'')}</div></div><button class="close-modal" onclick="closeDecision()">×</button></div>
    <div class="detail-grid"><div class="detail-cell"><span>Эффективный стек</span><b>${fmt(d.effective_stack_bb,1)} BB</b></div><div class="detail-cell"><span>Банк до действия</span><b>${fmt(d.pot_before_bb,1)} BB</b></div><div class="detail-cell"><span>Ставка к коллу</span><b>${fmt(d.facing_bet_bb,1)} BB</b></div><div class="detail-cell"><span>Доска</span><b>${escapeHtml(d.board||'—')}</b></div></div>
    <div class="detail-section"><h3>Твоё действие</h3><div class="action-line" style="color:#ffd27a;font-weight:800">${escapeHtml(d.action_taken)}</div></div>
    <div class="detail-section"><h3>Линия до решения</h3>${actions}</div>
    <div class="detail-section"><h3>Сравнение с GTO-референсом</h3>${analysisHtml}</div>
    ${!isPre&&state.solverTrees.length?`<button class="btn btn-secondary full" onclick="openSolverPicker(${index})">Подобрать точный узел из TexasSolver JSON</button>`:''}
    <div class="tiny-note">PKO/ICM не рассчитывается. Частота из смешанной стратегии не является оценкой ошибки. Разбор предназначен для завершённых раздач.</div>
  </div></div>`;
  document.getElementById('modal-root').innerHTML=html;
}
function renderMix(mix){
  if(!mix||!Object.keys(mix).length)return '';
  const colors={raise:'#f5a623',call:'#65a7ff',fold:'#72849b',limp:'#a899ff',check:'#54d6a2'};
  const segments=Object.entries(mix).filter(([k,v])=>Number(v)>0).map(([k,v])=>`<div class="mix-segment" title="${escapeHtml(k)} ${Math.round(v*100)}%" style="width:${Math.max(0,Math.min(100,Number(v)*100))}%;background:${colors[k]||'#54d6a2'}"></div>`).join('');
  const rows=Object.entries(mix).map(([k,v])=>`<div class="mix-row"><span>${escapeHtml(k)}</span><b>${Math.round(Number(v)*100)}%</b></div>`).join('');
  return `<div class="mix-bar">${segments}</div>${rows}`;
}
function comboKey(value){
  const raw=String(value||'').replace(/[\s,|/-]/g,'');if(raw.length!==4)return raw.toLowerCase();
  const cards=[raw[0].toUpperCase()+raw[1].toLowerCase(),raw[2].toUpperCase()+raw[3].toLowerCase()];
  if(cards.some(c=>!/[2-9TJQKA][shdc]/.test(c)))return raw.toLowerCase();return cards.sort().join('');
}
function normalizeSolverAction(label){
  const raw=String(label).trim().toUpperCase().replace(/_/g,' ');
  if(['CHECK','FOLD','CALL'].includes(raw))return raw.toLowerCase();
  if(['ALLIN','ALL IN','JAM'].includes(raw))return 'jam';
  const m=raw.match(/^(BET|RAISE|DONK)\s+([0-9]+(?:\.[0-9]+)?)$/);
  if(m){const kind=m[1]==='DONK'?'bet':m[1].toLowerCase();return `${kind}_${Math.round(Number(m[2]))}`;}
  return raw.toLowerCase().replace(/[^a-z0-9]+/g,'_').replace(/^_|_$/g,'');
}
function indexSolverTree(tree){
  const rows=[];
  function strategyBundle(node){
    const raw=node&&node.strategy&&typeof node.strategy==='object'?node.strategy:{};
    // Original TexasSolver dump_result wraps the combo map in strategy.strategy
    // and keeps action EV vectors beside it as strategy.evs.
    const combos=raw.strategy&&typeof raw.strategy==='object'&&!Array.isArray(raw.strategy)?raw.strategy:raw;
    const clean={};
    for(const [hand,values] of Object.entries(combos)){
      if(hand==='evs'||hand==='strategy'||hand==='actions'||hand==='player')continue;
      if(Array.isArray(values))clean[hand]=values;
    }
    const evs=raw.evs&&typeof raw.evs==='object'?raw.evs:(node.evs&&typeof node.evs==='object'?node.evs:{});
    return {combos:clean,evs};
  }
  function walk(node,path){
    if(!node||typeof node!=='object')return;
    const type=String(node.node_type||node.type||'').toLowerCase().replace(/[ _-]+/g,'');
    if(type==='actionnode'||type==='action'){
      const id=sha256(path.join('/')).slice(0,12);
      const actions=Array.isArray(node.actions)?node.actions:(Array.isArray(node.valid_actions)?node.valid_actions:[]);
      const bundle=strategyBundle(node),strategy=bundle.combos;
      rows.push({node_id:id,path:path.slice(),path_text:path.length?path.join(' / '):'ROOT',actions,strategy,evs:bundle.evs,strategy_hands:Object.keys(strategy).length,sample:Object.keys(strategy).slice(0,8),player:node.player??null});
    }
    const children=node.childrens;
    if(Array.isArray(children))children.forEach((child,i)=>walk(child,path.concat([String(node.actions?.[i]||node.valid_actions?.[i]||`ACTION ${i+1}`)])));
    else if(children&&typeof children==='object')for(const [action,child] of Object.entries(children))walk(child,path.concat([String(action)]));
    // Original TexasSolver inserts chance-card branches under `dealcards`.
    const deals=node.dealcards;
    if(deals&&typeof deals==='object')for(const [card,child] of Object.entries(deals))walk(child,path.concat([`BOARD ${card}`]));
  }
  walk(tree,[]);return rows;
}
function openSolverPicker(decisionIndex){
  const d=state.decisions[decisionIndex];if(!d||!d.hole_cards){showToast('В этой раздаче не распознаны две карты Hero.');return;}
  const wanted=comboKey(d.hole_cards);
  const blockers=new Set((String(d.board||'').match(/[2-9TJQKA][shdc]/gi)||[]).map(x=>x.toLowerCase()));
  let matches=[];
  state.solverTrees.forEach((entry,treeIndex)=>{
    const rows=indexSolverTree(entry.tree);
    rows.forEach(r=>{
      const pathCards=(r.path_text.match(/BOARD\s+([2-9TJQKA][shdc])/gi)||[]).map(x=>x.split(/\s+/)[1].toLowerCase());
      const unavailable=new Set([...blockers,...pathCards]);
      const combo=Object.entries(r.strategy).find(([k])=>{
        if(comboKey(k)!==wanted)return false;
        const cards=String(k).match(/[2-9TJQKA][shdc]/gi)||[];
        return cards.length===2&&!cards.some(c=>unavailable.has(c.toLowerCase()));
      });
      if(combo)matches.push({treeIndex,node:r,comboKey:combo[0],name:entry.name});
    });
  });
  const root=document.getElementById('modal-root');
  if(!matches.length){showToast('Ни в одном узле нет точной физической комбинации '+d.hole_cards+'.');return;}
  const body=matches.slice(0,120).map((m,i)=>`<button class="decision-item" style="width:100%;text-align:left" onclick="attachSolverNode(${decisionIndex},${m.treeIndex},'${escapeHtml(m.node.node_id)}')"><div class="decision-top"><b>${escapeHtml(m.node.path_text)}</b><span class="street-pill post">${m.node.strategy_hands} combos</span></div><div class="decision-meta">${escapeHtml(m.name)} · ${escapeHtml(m.node.actions.join(' / '))}</div></button>`).join('');
  root.innerHTML=`<div class="modal-backdrop" onclick="closeDecision(event)"><div class="modal" onclick="event.stopPropagation()"><div class="modal-handle"></div><div class="modal-head"><div><h2>Выбрать узел солвера</h2><div class="modal-sub">Точная комбинация ${escapeHtml(d.hole_cards)} · найдено ${matches.length} узлов</div></div><button class="close-modal" onclick="openDecision(${decisionIndex})">×</button></div><div class="tiny-note">Совместимые с доской комбинации уже отфильтрованы. Проверь путь действий и улицу: узел всё равно нужно вручную сверить с историей Hero.</div><div class="decision-list" style="margin-top:12px">${body}</div></div></div>`;
}
async function attachSolverNode(decisionIndex,treeIndex,nodeId){
  const d=state.decisions[decisionIndex],entry=state.solverTrees[treeIndex];if(!d||!entry)return;
  const row=indexSolverTree(entry.tree).find(x=>x.node_id===nodeId);if(!row){showToast('Узел больше не найден.');return;}
  const wanted=comboKey(d.hole_cards);const found=Object.entries(row.strategy).find(([k])=>comboKey(k)===wanted);
  if(!found){showToast('Точная комбинация отсутствует в выбранном узле.');return;}
  const actions=row.actions,values=found[1];if(!Array.isArray(values)||actions.length!==values.length){showToast('Количество действий и частот не совпадает.');return;}
  const freqs=values.map(Number);if(freqs.some(x=>!Number.isFinite(x)||x<-.001||x>1.001)||Math.abs(freqs.reduce((a,b)=>a+b,0)-1)>.03){showToast('Некорректные частоты стратегии.');return;}
  const strategy={};for(let i=0;i<actions.length;i++){const k=normalizeSolverAction(actions[i]);if(Object.prototype.hasOwnProperty.call(strategy,k)){showToast('Два действия имеют один нормализованный ярлык — импорт остановлен.');return;}strategy[k]=Number(freqs[i].toFixed(6));}
  const rawEv=row.evs&&typeof row.evs==='object'?Object.entries(row.evs).find(([k])=>comboKey(k)===wanted):null;
  const actionEv=rawEv&&Array.isArray(rawEv[1])&&rawEv[1].length===actions.length?rawEv[1].map(Number):null;
  const record={key:d.spot_key,source:`TexasSolver import · ${entry.name} · ${row.path_text}`,strategy,
    solver_meta:{engine:'TexasSolver',tree_node_id:nodeId,tree_path:row.path,exact_combo:found[0],ev_values:actionEv,ev_unit:'solver_native_unverified'}};
  state.solverLibrary.nodes=(state.solverLibrary.nodes||[]).filter(n=>n.key!==d.spot_key);state.solverLibrary.nodes.push(record);
  await saveState();renderAll();openDecision(decisionIndex);showToast('Стратегия точной комбинации добавлена в библиотеку.');
}
function closeDecision(e){if(e&&e.target&&!e.target.classList.contains('modal-backdrop'))return;document.getElementById('modal-root').innerHTML='';}

function buildDrillScenarios(){
  const out=[];
  for(const [stack,data] of Object.entries(state.ranges||{})){
    if(!data||typeof data!=='object')continue;
    for(const key of Object.keys(data)){
      let type=null,callKey=null;
      if(key.startsWith('Open')){type='open';callKey='Limp'+key.slice(4);}
      else if(key.startsWith('3Bet')){type='vs_open';callKey='Call'+key.slice(4);}
      else if(key.startsWith('4Bet')){type='vs_3bet';callKey='Call 3Bet'+key.slice(4);}
      else if(key.startsWith('5Bet')){type='vs_4bet';callKey='Call 4Bet'+key.slice(4);}
      if(!type||!Object.prototype.hasOwnProperty.call(data,callKey))continue;
      const hands=new Set([...Object.keys(data[key]||{}),...Object.keys(data[callKey]||{})]);
      for(const hand of hands){
        const raise=Number(data[key]?.[hand]||0),call=Number(data[callKey]?.[hand]||0),fold=1-raise-call;
        if(!Number.isFinite(raise)||!Number.isFinite(call)||fold<-.02||raise<0||call<0)continue;
        const mix={raise,fold:Math.max(0,fold)};mix[type==='open'?'limp':'call']=call;
        out.push({stack:Number(stack),type,key,callKey,hand,mix});
      }
    }
  }
  return out;
}
function startDrill(){
  const selectedStack=document.getElementById('drill-stack')?.value||'any';const selectedType=document.getElementById('drill-type')?.value||'any';
  let pool=buildDrillScenarios();if(selectedStack!=='any')pool=pool.filter(x=>x.stack===Number(selectedStack));if(selectedType!=='any')pool=pool.filter(x=>x.type===selectedType);
  if(!pool.length){showToast('Нет спотов по этому фильтру. Загрузите диапазоны или выберите другую глубину.');return;}
  currentQuiz=pool[Math.floor(Math.random()*pool.length)];renderDrillQuestion();
}
function renderDrillQuestion(){
  const q=currentQuiz,root=document.getElementById('drill-card');if(!q||!root)return;
  const scenarioLabel={open:'OPEN · НЕОТКРЫТЫЙ ПОТ',vs_open:'VS OPEN · ЗАЩИТА',vs_3bet:'VS 3-BET · РЕШЕНИЕ',vs_4bet:'VS 4-BET · РЕШЕНИЕ'}[q.type]||q.type;
  const suffix=q.key.replace(/^(Open|3Bet|4Bet|5Bet)/,'');
  const actionList=q.type==='open'?['raise','limp','fold']:['raise','call','fold'];
  root.className='drill-card question';root.innerHTML=`<div class="drill-title">${scenarioLabel} · ${q.stack} BB</div><div class="drill-hand">${escapeHtml(q.hand)}</div><div class="drill-context">${escapeHtml(suffix)} · Выбери действие для этой руки</div><div class="drill-options">${actionList.map(a=>`<button class="drill-answer" onclick="answerDrill('${a}')">${a.toUpperCase()}</button>`).join('')}</div><div id="drill-feedback"></div>`;
}
function answerDrill(action){
  if(!currentQuiz)return;const q=currentQuiz;const freq=Number(q.mix[action]||0);const inMix=freq>0;
  quizAttempts++;if(inMix)quizInMix++;
  document.querySelectorAll('.drill-answer').forEach(b=>b.disabled=true);
  const correct=Object.entries(q.mix).sort((a,b)=>b[1]-a[1]).filter(x=>x[1]>.001).map(([k])=>k);
  const feedback=document.getElementById('drill-feedback');feedback.innerHTML=`<div class="drill-result ${inMix?'':'warn'}"><b>${inMix?'Действие есть в смешанной стратегии':'Действие отсутствует в этой стратегии'}</b><p>${action.toUpperCase()}: ${Math.round(freq*100)}%. Наиболее частые варианты: ${correct.join(' / ')}. Это не EV-оценка и не результат PKO/ICM-решения.</p>${renderMix(q.mix)}</div><button class="btn btn-primary full" onclick="startDrill()">Следующий спот</button>`;
  document.getElementById('drill-score').textContent=`Ответы в этой тренировке: ${quizAttempts} · В миксе: ${quizInMix}`;
}
// Bridge callbacks are called by the Android native host after SAF import/export or data download.
if(typeof window!=='undefined'){
  window.onNativeImport=onNativeImport;window.onNativeImportError=onNativeImportError;
  window.onNativeRangesDownloaded=onNativeRangesDownloaded;window.onNativeRangeDownloadError=onNativeRangeDownloadError;
  window.onNativeExportSuccess=onNativeExportSuccess;window.onNativeExportError=onNativeExportError;
  window.pickImport=pickImport;window.downloadRanges=downloadRanges;window.switchPage=switchPage;
  window.renderDecisionList=renderDecisionList;window.openDecision=openDecision;window.closeDecision=closeDecision;
  window.exportBackup=exportBackup;window.exportCsv=exportCsv;window.clearDatabase=clearDatabase;
  window.openSolverPicker=openSolverPicker;window.attachSolverNode=attachSolverNode;window.startDrill=startDrill;window.answerDrill=answerDrill;
  window.addEventListener('DOMContentLoaded',loadState);
}
if(typeof module!=='undefined'&&module.exports){module.exports={parseGGText,parseHandBlock,buildDecisions,cardClass,positionBySeat,stableCanonicalContext,sha256,classifyScenario,evaluatePreflop,indexSolverTree,comboKey,normalizeSolverAction};}
