#!/usr/bin/env python3
"""Apply the first TexasSolver ARM64/JNI integration to an unpacked APS v0.6.0 tree."""
from __future__ import annotations
import gzip
import os
import re
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path.cwd()
BUNDLE = Path(__file__).resolve().parent
APP = ROOT / "app"
UPSTREAM_URL = "https://github.com/bupticybee/TexasSolver.git"
UPSTREAM_COMMIT = "02c8021ee1307c18aa1e76b772c6ae1451601bc6"


def run(command: list[str], cwd: Path | None = None) -> None:
    print("+", " ".join(command), flush=True)
    subprocess.run(command, cwd=str(cwd) if cwd else None, check=True)


def find_matching_brace(source: str, open_pos: int) -> int:
    depth = 0
    quote = None
    escape = False
    line_comment = False
    block_comment = False
    i = open_pos
    while i < len(source):
        ch = source[i]
        nxt = source[i + 1] if i + 1 < len(source) else ""
        if line_comment:
            if ch == "\n":
                line_comment = False
        elif block_comment:
            if ch == "*" and nxt == "/":
                block_comment = False
                i += 1
        elif quote:
            if escape:
                escape = False
            elif ch == "\\":
                escape = True
            elif ch == quote:
                quote = None
        else:
            if ch == "/" and nxt == "/":
                line_comment = True
                i += 1
            elif ch == "/" and nxt == "*":
                block_comment = True
                i += 1
            elif ch in ("'", '"'):
                quote = ch
            elif ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    return i
        i += 1
    raise RuntimeError("Unbalanced braces while patching app/build.gradle.kts")


def locate_block(source: str, block_name: str, start: int = 0) -> tuple[int, int, int]:
    match = re.search(r"(?m)^\s*" + re.escape(block_name) + r"\s*\{", source[start:])
    if not match:
        raise RuntimeError(f"Cannot find {block_name} {{ block in app/build.gradle.kts")
    begin = start + match.start()
    opening = source.find("{", begin)
    return begin, opening, find_matching_brace(source, opening)


def patch_gradle(path: Path) -> None:
    source = path.read_text(encoding="utf-8")
    if "src/main/cpp/CMakeLists.txt" in source:
        print("Gradle native configuration already exists; leaving it in place")
        return

    _, android_open, android_close = locate_block(source, "android")
    _, default_open, default_close = locate_block(source, "defaultConfig", android_open)
    default_body = source[default_open + 1:default_close]
    default_additions = ""
    if "abiFilters" not in default_body:
        default_additions += '\n        ndk { abiFilters += setOf("arm64-v8a") }\n'
    if "externalNativeBuild" not in default_body:
        default_additions += '''
        externalNativeBuild {
            cmake {
                cppFlags += listOf("-std=c++17", "-O3", "-Wno-unknown-pragmas")
            }
        }
'''
    source = source[:default_close] + default_additions + source[default_close:]

    # Re-locate the android block because the defaultConfig insertion changed offsets.
    _, android_open, android_close = locate_block(source, "android")
    android_body = source[android_open + 1:android_close]
    additions = ""
    if "ndkVersion" not in android_body:
        additions += '\n    ndkVersion = "27.2.12479018"\n'
    if "src/main/cpp/CMakeLists.txt" not in android_body:
        additions += '''
    externalNativeBuild {
        cmake {
            path = file("src/main/cpp/CMakeLists.txt")
            version = "3.22.1"
        }
    }
'''
    source = source[:android_close] + additions + source[android_close:]
    path.write_text(source, encoding="utf-8")


def mangle_jni_package(package: str, method: str) -> str:
    encoded = package.replace("_", "_1").replace(".", "_").replace("$", "_00024")
    return "Java_" + encoded + "_TexasSolverBridge_" + method


def patch_main_activity(main_activity: Path, package: str) -> None:
    source = main_activity.read_text(encoding="utf-8")
    if "TexasSolverBridge" in source:
        print("MainActivity already exposes TexasSolver")
        return

    # Prefer the local Android asset URL; fall back to the first WebView loadUrl call.
    match = re.search(
        r"(?m)^(?P<indent>[ \t]*)(?P<view>[A-Za-z_$][\w$]*)\.loadUrl\(\s*\"file:///android_asset/[^\"]+\"",
        source,
    )
    if not match:
        match = re.search(
            r"(?m)^(?P<indent>[ \t]*)(?P<view>[A-Za-z_$][\w$]*)\.loadUrl\(", source
        )
    if not match:
        raise RuntimeError(
            "Could not identify the WebView loadUrl line in MainActivity.java. "
            "Native files were staged, but the JavascriptInterface hook was not inserted."
        )

    indent = match.group("indent")
    view = match.group("view")
    insertion = f'{indent}{view}.addJavascriptInterface(new TexasSolverBridge(this, {view}), "TexasSolver");\n'
    source = source[:match.start()] + insertion + source[match.start():]
    main_activity.write_text(source, encoding="utf-8")


def main() -> int:
    if not APP.is_dir():
        raise RuntimeError("app/ directory not found. Run this script after unpacking AdaptivePokerStudy_v060.zip.")

    gradle_file = APP / "build.gradle.kts"
    assets = APP / "src/main/assets"
    cpp_dir = APP / "src/main/cpp"
    java_root = APP / "src/main/java"
    if not gradle_file.is_file() or not assets.is_dir() or not java_root.is_dir():
        raise RuntimeError("Expected Android Gradle, assets, or Java source tree is missing")

    main_files = list(java_root.rglob("MainActivity.java"))
    if len(main_files) != 1:
        raise RuntimeError(f"Expected one MainActivity.java, found {len(main_files)}")
    main_activity = main_files[0]
    package_match = re.search(r"(?m)^\s*package\s+([A-Za-z0-9_.]+)\s*;", main_activity.read_text(encoding="utf-8"))
    if not package_match:
        raise RuntimeError("Cannot determine Java package from MainActivity.java")
    package = package_match.group(1)
    package_dir = java_root.joinpath(*package.split("."))
    package_dir.mkdir(parents=True, exist_ok=True)

    upstream = ROOT / ".texassolver-upstream"
    if not upstream.exists():
        upstream.mkdir(parents=True)
        run(["git", "init"], upstream)
        run(["git", "remote", "add", "origin", UPSTREAM_URL], upstream)
        run(["git", "fetch", "--depth", "1", "origin", UPSTREAM_COMMIT], upstream)
        run(["git", "checkout", "--detach", "FETCH_HEAD"], upstream)

    actual_commit = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=str(upstream), text=True).strip()
    if actual_commit != UPSTREAM_COMMIT:
        raise RuntimeError(f"Wrong TexasSolver revision: {actual_commit}")

    required_upstream = [
        "src/runtime/PokerSolver.cpp",
        "src/tools/CommandLineTool.cpp",
        "src/solver/PCfrSolver.cpp",
        "src/compairer/Dic5Compairer.cpp",
        "ext/fmt/src/format.cc",
        "resources/compairer/card5_dic_sorted.txt",
    ]
    missing = [name for name in required_upstream if not (upstream / name).is_file()]
    if missing:
        raise RuntimeError("Pinned TexasSolver source is incomplete: " + ", ".join(missing))

    cpp_dir.mkdir(parents=True, exist_ok=True)
    for folder in ("src", "include", "ext/fmt"):
        source_dir = upstream / folder
        destination = cpp_dir / "texassolver" / folder
        if destination.exists():
            shutil.rmtree(destination)
        shutil.copytree(source_dir, destination)

    native_bundle = BUNDLE / "native"
    shutil.copy2(native_bundle / "CMakeLists.txt", cpp_dir / "CMakeLists.txt")
    shutil.copy2(native_bundle / "texassolver_jni.cpp", cpp_dir / "texassolver_jni.cpp")
    compat_destination = cpp_dir / "compat"
    if compat_destination.exists():
        shutil.rmtree(compat_destination)
    shutil.copytree(native_bundle / "compat", compat_destination)

    jni_source = cpp_dir / "texassolver_jni.cpp"
    jni_text = jni_source.read_text(encoding="utf-8")
    jni_text = re.sub(
        r"Java_[A-Za-z0-9_]+_TexasSolverBridge_(nativeRun|nativeVersion)",
        lambda match: mangle_jni_package(package, match.group(1)),
        jni_text,
    )
    jni_source.write_text(jni_text, encoding="utf-8")

    java_template = (native_bundle / "TexasSolverBridge.java.in").read_text(encoding="utf-8")
    java_source = java_template.replace("__PACKAGE__", package)
    (package_dir / "TexasSolverBridge.java").write_text(java_source, encoding="utf-8")

    # Compress the upstream 7-card evaluator dictionary into the APK assets.
    solver_assets = assets / "solver"
    solver_assets.mkdir(parents=True, exist_ok=True)
    dictionary = upstream / "resources/compairer/card5_dic_sorted.txt"
    if not dictionary.is_file() or dictionary.stat().st_size < 50_000_000:
        raise RuntimeError("Upstream Hold'em evaluator dictionary is missing or unexpectedly small")
    compressed = solver_assets / "card5_dic_sorted.txt.gz"
    with dictionary.open("rb") as source, gzip.open(compressed, "wb", compresslevel=9) as target:
        shutil.copyfileobj(source, target, length=1024 * 1024)
    if compressed.stat().st_size < 1_000_000:
        raise RuntimeError("Compressed evaluator dictionary looks incomplete")

    license_dir = assets / "licenses"
    license_dir.mkdir(parents=True, exist_ok=True)
    shutil.copy2(upstream / "LICENSE", license_dir / "TexasSolver-LICENSE-AGPL-3.0.txt")
    fmt_license = upstream / "ext/fmt/LICENSE.rst"
    if fmt_license.is_file():
        shutil.copy2(fmt_license, license_dir / "fmt-LICENSE.rst")
    json_header = upstream / "include/json.hpp"
    if json_header.is_file():
        header_text = json_header.read_text(encoding="utf-8", errors="replace")
        # json.hpp 3.x carries its complete MIT notice at the top of the header.
        notice = header_text.split("*/", 1)[0] + "*/\n" if "*/" in header_text[:5000] else ""
        if notice:
            (license_dir / "nlohmann-json-LICENSE.txt").write_text(notice, encoding="utf-8")

    patch_gradle(gradle_file)
    patch_main_activity(main_activity, package)

    ui_source = (native_bundle / "solver-ui.js").read_text(encoding="utf-8")
    ui_target = assets / "solver-ui.js"
    ui_target.write_text(ui_source, encoding="utf-8")
    html_path = assets / "index.html"
    html = html_path.read_text(encoding="utf-8")
    if "solver-ui.js" not in html:
        script = '\n<script src="solver-ui.js"></script>\n'
        if re.search(r"</body\s*>", html, re.IGNORECASE):
            html = re.sub(r"</body\s*>", script + "</body>", html, count=1, flags=re.IGNORECASE)
        else:
            html += script
        html_path.write_text(html, encoding="utf-8")

    print("TexasSolver Android integration patch applied.")
    print("Package:", package)
    print("C++ engine source pinned to:", UPSTREAM_COMMIT)
    print("Evaluator asset size:", compressed.stat().st_size, "bytes (gzip)")
    print("License notices copied: TexasSolver AGPL-3.0, fmt and nlohmann/json when present")
    print("Next: run ./gradlew assembleDebug (or gradle assembleDebug in CI).")
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except Exception as exc:
        print("NATIVE PORT SETUP FAILED:", exc, file=sys.stderr)
        sys.exit(1)
