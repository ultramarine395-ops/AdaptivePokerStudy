#include <jni.h>

#include <exception>
#include <iostream>
#include <mutex>
#include <memory>
#include <sstream>
#include <string>

#include "tools/CommandLineTool.h"

namespace {
std::mutex g_solver_mutex;
std::unique_ptr<CommandLineTool> g_solver;
std::string g_solver_resource;

std::string from_java(JNIEnv* env, jstring value) {
    if (value == nullptr) return {};
    const char* chars = env->GetStringUTFChars(value, nullptr);
    if (chars == nullptr) return {};
    std::string result(chars);
    env->ReleaseStringUTFChars(value, chars);
    return result;
}
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_adaptivepoker_study_TexasSolverBridge_nativeRun(
        JNIEnv* env, jclass, jstring resource_dir, jstring input_file) {
    const std::string resource = from_java(env, resource_dir);
    const std::string input = from_java(env, input_file);
    if (resource.empty() || input.empty()) {
        return env->NewStringUTF("ERROR: resource directory or input file is empty");
    }

    std::lock_guard<std::mutex> lock(g_solver_mutex);
    std::ostringstream captured;
    std::streambuf* old_out = std::cout.rdbuf(captured.rdbuf());
    std::streambuf* old_err = std::cerr.rdbuf(captured.rdbuf());
    try {
        if (!g_solver || g_solver_resource != resource) {
            g_solver = std::make_unique<CommandLineTool>("holdem", resource);
            g_solver_resource = resource;
        }
        g_solver->execFromFile(input);
        std::cout.rdbuf(old_out);
        std::cerr.rdbuf(old_err);
        std::string log = captured.str();
        if (log.size() > 120000) {
            log = log.substr(log.size() - 120000);
            log = "[Earlier log output truncated]\n" + log;
        }
        return env->NewStringUTF(log.c_str());
    } catch (const std::exception& error) {
        std::cout.rdbuf(old_out);
        std::cerr.rdbuf(old_err);
        std::string log = "ERROR: ";
        log += error.what();
        log += "\n";
        log += captured.str();
        if (log.size() > 120000) log.resize(120000);
        return env->NewStringUTF(log.c_str());
    } catch (...) {
        std::cout.rdbuf(old_out);
        std::cerr.rdbuf(old_err);
        return env->NewStringUTF("ERROR: Unknown native TexasSolver failure");
    }
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_adaptivepoker_study_TexasSolverBridge_nativeVersion(
        JNIEnv* env, jclass) {
    return env->NewStringUTF("TexasSolver C++ engine / Android ARM64 / single-thread / upstream 02c8021");
}
