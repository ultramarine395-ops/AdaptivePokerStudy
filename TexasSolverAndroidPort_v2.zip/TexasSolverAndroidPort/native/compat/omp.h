#pragma once

// Android bootstrap compatibility layer for the original TexasSolver
// console core. OpenMP pragmas are intentionally ignored in this first
// mobile build, so the engine is deterministic and single-threaded.
static inline int omp_get_num_procs(void) { return 1; }
static inline void omp_set_num_threads(int) {}
