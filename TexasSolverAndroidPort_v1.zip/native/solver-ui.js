(() => {
  'use strict';
  if (window.__apsTexasSolverInstalled) return;
  window.__apsTexasSolverInstalled = true;

  const style = document.createElement('style');
  style.textContent = `
    #aps-solver-launch { position:fixed; right:16px; bottom:calc(16px + env(safe-area-inset-bottom)); z-index:99990; border:0; border-radius:999px; padding:13px 17px; color:#fff; background:#244b72; box-shadow:0 5px 18px #0004; font:600 14px system-ui,sans-serif; }
    #aps-solver-overlay { position:fixed; inset:0; z-index:99999; display:none; background:rgba(0,0,0,.68); padding:env(safe-area-inset-top) 10px env(safe-area-inset-bottom); box-sizing:border-box; }
    #aps-solver-panel { height:100%; max-width:620px; margin:0 auto; overflow:auto; background:var(--bg,#fff); color:var(--fg,#17202a); border-radius:16px; padding:16px; box-sizing:border-box; font:14px system-ui,sans-serif; }
    #aps-solver-panel h2 { margin:4px 0 8px; font-size:20px; }
    #aps-solver-panel p { line-height:1.45; }
    #aps-solver-panel label { display:block; margin:11px 0 5px; font-weight:600; }
    #aps-solver-panel input, #aps-solver-panel textarea, #aps-solver-panel select { width:100%; padding:10px; box-sizing:border-box; border:1px solid #9aa6b2; border-radius:9px; background:var(--input-bg,#fff); color:var(--fg,#17202a); font:14px system-ui,sans-serif; }
    #aps-solver-panel textarea { min-height:66px; resize:vertical; }
    #aps-solver-panel .aps-row { display:grid; grid-template-columns:1fr 1fr; gap:10px; }
    #aps-solver-panel .aps-actions { position:sticky; bottom:-16px; display:flex; gap:10px; padding:12px 0 max(12px,env(safe-area-inset-bottom)); background:var(--bg,#fff); }
    #aps-solver-panel button { border:0; border-radius:9px; padding:11px 14px; font-weight:700; }
    #aps-solver-run { flex:1; background:#244b72; color:white; }
    #aps-solver-close { background:#e7ebef; color:#17202a; }
    #aps-solver-status { padding:10px; border-radius:9px; background:rgba(120,130,140,.12); white-space:pre-wrap; overflow-wrap:anywhere; max-height:240px; overflow:auto; }
    #aps-solver-warning { font-size:12px; opacity:.8; }
  `;
  document.head.appendChild(style);

  const overlay = document.createElement('div');
  overlay.id = 'aps-solver-overlay';
  overlay.innerHTML = `
    <section id="aps-solver-panel" role="dialog" aria-modal="true" aria-label="TexasSolver">
      <h2>TexasSolver · Postflop</h2>
      <p>Локальный расчёт на телефоне. Укажите завершённый постфлоп-спот и диапазоны обеих сторон.</p>
      <label for="aps-board">Борд (3–5 карт)</label>
      <input id="aps-board" value="Qs,Jh,2h" autocomplete="off" spellcheck="false">
      <div class="aps-row">
        <div><label for="aps-pot">Пот</label><input id="aps-pot" type="number" min="1" step="0.5" value="50"></div>
        <div><label for="aps-stack">Эффективный стек</label><input id="aps-stack" type="number" min="1" step="1" value="100"></div>
      </div>
      <label for="aps-ip">Диапазон IP</label>
      <textarea id="aps-ip" spellcheck="false">AA,KK,QQ,JJ,TT,99,AKs,AQs,AJs,KQs</textarea>
      <label for="aps-oop">Диапазон OOP</label>
      <textarea id="aps-oop" spellcheck="false">QQ,JJ,TT,99,88,77,AKo,AQs,AJs,KQs,KJs</textarea>
      <div class="aps-row">
        <div><label for="aps-iterations">Итерации</label><input id="aps-iterations" type="number" min="50" max="2000" step="50" value="200"></div>
        <div><label for="aps-accuracy">Точность (порог)</label><input id="aps-accuracy" type="number" min="0.01" max="10" step="0.05" value="0.5"></div>
      </div>
      <p id="aps-solver-warning">Первый запуск распакует справочник комбинаций (около 52 МБ). Расчёт выполняется в одном потоке; широкие диапазоны и сложные деревья могут занять много памяти и времени. Используйте только для анализа завершённых раздач, не во время игры.</p>
      <div id="aps-solver-status" aria-live="polite">Готов к запуску.</div>
      <div class="aps-actions"><button id="aps-solver-close" type="button">Закрыть</button><button id="aps-solver-run" type="button">Запустить solve</button></div>
    </section>`;
  document.body.appendChild(overlay);

  const launch = document.createElement('button');
  launch.id = 'aps-solver-launch';
  launch.type = 'button';
  launch.textContent = 'TexasSolver';
  document.body.appendChild(launch);

  const status = overlay.querySelector('#aps-solver-status');
  const run = overlay.querySelector('#aps-solver-run');
  const close = () => { overlay.style.display = 'none'; };
  launch.addEventListener('click', () => {
    overlay.style.display = 'block';
    status.textContent = (window.TexasSolver && window.TexasSolver.version) ? window.TexasSolver.version() : 'Нативный модуль пока не подключён';
  });
  overlay.addEventListener('click', e => { if (e.target === overlay) close(); });
  overlay.querySelector('#aps-solver-close').addEventListener('click', close);

  run.addEventListener('click', () => {
    if (!window.TexasSolver || typeof window.TexasSolver.solve !== 'function') {
      status.textContent = 'Ошибка: нативный модуль TexasSolver не загружен.';
      return;
    }
    const payload = {
      board: overlay.querySelector('#aps-board').value.trim(),
      pot: Number(overlay.querySelector('#aps-pot').value),
      effectiveStack: Number(overlay.querySelector('#aps-stack').value),
      rangeIp: overlay.querySelector('#aps-ip').value.replace(/\s+/g, ''),
      rangeOop: overlay.querySelector('#aps-oop').value.replace(/\s+/g, ''),
      iterations: Number(overlay.querySelector('#aps-iterations').value),
      accuracy: Number(overlay.querySelector('#aps-accuracy').value)
    };
    if (!payload.board || !payload.rangeIp || !payload.rangeOop || !Number.isFinite(payload.pot) || !Number.isFinite(payload.effectiveStack)) {
      status.textContent = 'Заполните борд, оба диапазона, пот и эффективный стек.';
      return;
    }
    run.disabled = true;
    run.textContent = 'Вычисление…';
    status.textContent = 'Подготовка справочника и запуск TexasSolver. Не закрывайте приложение.';
    window.TexasSolver.solve(JSON.stringify(payload));
  });

  window.addEventListener('aps-texassolver-result', event => {
    const result = event.detail || {};
    run.disabled = false;
    run.textContent = 'Запустить solve';
    status.textContent = (result.ok ? 'Готово. ' : 'Ошибка. ') + (result.message || '');
    if (result.file) status.textContent += '\nФайл результата: ' + result.file;
  });
})();
