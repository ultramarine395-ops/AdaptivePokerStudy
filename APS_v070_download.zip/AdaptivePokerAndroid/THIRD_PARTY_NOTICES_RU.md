# Сторонние компоненты

## GTOpen

Upstream: https://github.com/MatthewPDingle/GTOpen

Используется только crate `crates/solver` из репозитория MatthewPDingle/GTOpen, commit `153f41f186037014646f3a63158a5636e58ef8a3`. GTOpen server, web UI и удалённый сервис не используются. Владелец приложения сообщил, что автор GTOpen напрямую разрешил использование кода в приложении. В upstream-репозитории на указанном commit не обнаружен стандартный файл LICENSE. Прямое разрешение не следует автоматически трактовать как общую open-source лицензию или право выдавать сублицензии; сохраняйте исходную переписку и уточняйте условия коммерческого распространения/публикации, если они изменятся.

## TexasSolver

Upstream: https://github.com/bupticybee/TexasSolver

TexasSolver upstream commit `02c8021ee1307c18aa1e76b772c6ae1451601bc6` интегрируется сборочным скриптом. Upstream распространяется под GNU Affero General Public License v3.0 (AGPL-3.0). Сборка копирует оригинальный LICENSE в `app/src/main/assets/licenses/TexasSolver-LICENSE-AGPL-3.0.txt`. При распространении APK соблюдайте требования AGPL, включая предоставление соответствующего исходного кода и сохранение уведомлений.

## fmt и nlohmann/json

Лицензионные уведомления соответствующих upstream-компонентов копируются сборочным скриптом в `app/src/main/assets/licenses/`.
