'use strict';
const assert = require('node:assert/strict');
const core = require('../app/src/main/assets/app.js');

assert.equal(core.sha256('abc'), 'ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad');
assert.equal(core.cardClass(['As', 'Kd']), 'AKo');
assert.equal(core.cardClass(['Kd', 'As']), 'AKo');
assert.equal(core.cardClass(['9h', '9d']), '99');
assert.equal(core.cardClass(['2x', 'As']), null);
assert.equal(core.comboKey('Kd As'), core.comboKey('AsKd'));
assert.equal(core.normalizeSolverAction('BET 50'), 'bet_50');
assert.equal(core.normalizeSolverAction('ALL IN'), 'jam');
assert.equal(core.normalizeSolverAction('CHECK'), 'check');

const history = [
  'BTN:raise_to_2.50bb',
  'SB:call'
];
const scenario = core.classifyScenario('BB', 6, history);
assert.equal(scenario, null, 'a call before Hero should not be guessed as a simple vs-open spot');
const vsOpen = core.classifyScenario('SB', 6, ['BTN:raise_to_2.50bb']);
assert.equal(vsOpen.type, 'vs_open');
assert.equal(vsOpen.villain, 'BTN');
const open = core.classifyScenario('CO', 6, ['UTG:fold', 'HJ:fold']);
assert.equal(open.type, 'open');

const tree = {
  node_type: 'action_node',
  actions: ['CHECK', 'BET 50'],
  strategy: {strategy: {'AsKd': [0.35, 0.65]}, evs: {'AsKd': [2.1, 2.8]}},
  childrens: {
    'CHECK': {
      node_type: 'chance_node',
      dealcards: {
        '2h': {
          node_type: 'action_node', actions: ['CHECK', 'BET 75'],
          strategy: {strategy: {'AsKd': [0.7, 0.3]}, evs: {'AsKd': [2.0, 2.3]}}, childrens: {}
        }
      }
    }
  }
};
const indexed = core.indexSolverTree(tree);
assert.equal(indexed.length, 2, 'index lowercase TexasSolver node_type plus chance-card branches');
assert.equal(indexed[0].strategy_hands, 1);
assert.equal(indexed[0].evs.AsKd[1], 2.8);
assert.equal(indexed[1].path_text, 'CHECK / BOARD 2h');

const sample = `Poker Hand #TMTEST001: Tournament #123, Test MTT $1 Hold'em No Limit - Level1(50/100(10)) - 2026/11/08 12:00:00
Table '1' 6-max Seat #1 is the button
Seat 1: Villain (10,000 in chips)
Seat 2: Hero (10,000 in chips)
Seat 3: Other (10,000 in chips)
Villain: posts the ante 10
Hero: posts the ante 10
Other: posts the ante 10
Hero: posts small blind 50
Other: posts big blind 100
*** HOLE CARDS ***
Dealt to Villain
Dealt to Hero [As Kd]
Dealt to Other
Villain: raises 150 to 250
Hero: calls 200
Other: folds
*** FLOP *** [2c 3d 4h]
Hero: checks
Other: checks
*** TURN *** [2c 3d 4h] [5s]
Hero: checks
*** RIVER *** [2c 3d 4h 5s] [6c]
Hero: checks
*** SHOWDOWN ***
Villain collected 600 from pot
*** SUMMARY ***
Total pot 600 | Rake 0
Board [2c 3d 4h 5s 6c]
Seat 1: Villain (button) won
Seat 2: Hero (small blind) showed [As Kd] and lost
Seat 3: Other (big blind) folded before Flop`;
const parsed = core.parseGGText(sample);
assert.equal(parsed.hands.length, 1);
assert.equal(parsed.decisions.length, 4);
assert.deepEqual(parsed.decisions.map(x => x.street), ['preflop', 'flop', 'turn', 'river']);
assert.equal(parsed.decisions[0].hole_cards, 'As Kd');
assert.ok(parsed.decisions.every(x => /^[a-f0-9]{64}$/.test(x.spot_key)));

console.log('Android core tests passed: 20 assertions');
