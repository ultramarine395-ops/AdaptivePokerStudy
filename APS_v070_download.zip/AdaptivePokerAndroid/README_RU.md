# Adaptive Poker Study — Android v0.7.0

Мобильное приложение для **послесессионного анализа завершённых раздач и GTO-тренировки**. Данные хранятся локально на устройстве. Приложение не читает экран покерного клиента, не показывает подсказки во время игры и не интегрируется с игровым столом.

## Что есть в этой версии

- Импорт GGPoker Hand History в TXT и ZIP через системный выбор файлов Android.
- Парсер и разбиение решений Hero по улицам.
- Префлоп-справочник generic MTT chip-EV с диапазонами 5/10/20/40/100 BB (загружается отдельным действием из публичного репозитория).
- Учебные случайные префлоп-споты и показ смешанных частот.
- Встроенный native GTOpen preflop engine (ARM64 CPU): 3-max Spin и 8-max MTT ChipEV, 169 классов рук, навигация по дереву, частоты и action EV.
- Импорт оригинального JSON-дерева TexasSolver (`action_node`, вложенный `strategy.strategy`, ветки `dealcards`), индекс узлов, выбор конкретной комбинации и добавление стратегии в локальную библиотеку.
- Экспорт CSV и JSON-бэкапа.
- Хранение в IndexedDB внутри Android WebView; после первоначальной загрузки диапазонов базовые функции работают офлайн.

## Важные ограничения стратегии

1. Публичные MTT-диапазоны — reference для generic chip-EV. Они не являются решением конкретного PKO-турнира.
2. ICM и баунти-эквити сейчас не рассчитываются.
3. Сборочный workflow интегрирует TexasSolver как native C++ ARM64 engine для heads-up постфлопа. Это отдельный модуль; он не решает префлоп и не является multiway-постфлоп солвером.
4. GTOpen preflop engine работает локально, без GTOpen server/browser/APK. Он поддерживает 2–9 игроков, но его продолжение после префлопа — приближённая equity-realization модель, а не полный solve до ривера. В multiway-ветках используется coupled-deck rank approximation; joint card-removal effects могут давать заметную ошибку.
5. Action EV GTOpen показывается в BB относительно фолда в текущем узле и рассчитан при продолжении через сохранённые средние стратегии. Это не $EV турнира и не ICM/PKO bounty EV.
6. Первый интерфейс GTOpen предлагает пресеты 3-max Spin и 8-max MTT с равными стеками, стандартными блайндами 0.5/1 BB и настраиваемыми ante/open/3-bet/max raises. Произвольные стеки по местам, ICM и PKO пока не включены.
7. Совпадение частоты выбранного действия не равно потере EV. В этой версии EV-векторы TexasSolver сохраняются только как исходные значения с неустановленной шкалой; EV loss в BB намеренно не рассчитывается.
8. Размеры BET/RAISE из TexasSolver могут быть заданы в абсолютных единицах исходного solve. Пока единицы и размер банка не подтверждены, приложение не переводит их автоматически в проценты и не обещает совпадение сайзинга.
9. При выборе узла приложение отсекает комбинации, конфликтующие с доской и раскрытыми картами ветви, но пользователь должен вручную проверить линию действий и улицу.
10. Если ситуация/узел не распознаны однозначно, приложение оставляет её без GTO-оценки.

## Native engines

- GTOpen solver core is fetched at build time from pinned commit `153f41f186037014646f3a63158a5636e58ef8a3`, compiled with Rust/NDK as `libaps_preflop_android.so`, and packaged into the APK. Only the solver crate is used; GTOpen's server and browser interface are not built or run.
- TexasSolver C++ is fetched at build time from pinned commit `02c8021ee1307c18aa1e76b772c6ae1451601bc6`, compiled with CMake/NDK as `libtexassolver_jni.so`. Its original AGPL-3.0 notice is copied into APK assets.
- The APK runs both engines offline. Build-time source fetching requires internet access in GitHub Actions; there is no GTOpen/TexasSolver runtime server dependency.
- GTOpen is used with direct permission from its author as reported by the project owner. The upstream repository does not include a standard license file; this permission should not be represented as a general open-source license or sublicense.

## Сборка APK через GitHub Actions

Для первого запуска из репозитория с ZIP-архивами:

1. Загрузи `AdaptivePokerStudy_v070.zip` в корень приватного репозитория.
2. Скопируй `BOOTSTRAP_ANDROID_ALL.yml` в `.github/workflows/bootstrap-android.yml` в корне репозитория (создай папки, если их нет).
3. Открой **Actions → Bootstrap and build AdaptivePokerStudy with GTOpen + TexasSolver → Run workflow**.
4. После успешной сборки скачай artifact `AdaptivePokerStudy-GTOpen-TexasSolver-arm64-debug`.

Workflow распакует проект, скачает закреплённые исходники двух движков, соберёт GTOpen Rust/JNI и TexasSolver C++/JNI для ARM64, проверит содержимое APK и загрузит готовый artifact. Сами движки в установленном приложении работают локально; сетевые обращения нужны только во время CI-сборки и для отдельной загрузки справочных MTT-диапазонов.

После распаковки исходников в корень репозитория можно использовать `.github/workflows/build-android-apk.yml` для последующих сборок.

## Локальная сборка

Нужны JDK 17, Android SDK Platform 37, Build Tools 36.0.0, NDK 27.2.12479018, CMake 3.22.1, Rust stable и `cargo-ndk`. Сначала выполни `python3 scripts/apply_texassolver_android.py`, затем шаги получения/патча GTOpen из `BOOTSTRAP_ANDROID_ALL.yml`, после чего:

```bash
cargo check --manifest-path rust/Cargo.toml --lib
cargo ndk -t arm64-v8a -o app/src/main/jniLibs build --manifest-path rust/Cargo.toml --release
gradle --no-daemon assembleDebug
```

APK появится в `app/build/outputs/apk/debug/app-debug.apk`. Для первого запуска проще использовать GitHub Actions workflow выше.

## Проверки

Проверено в среде подготовки:

- `node --check app/src/main/assets/app.js` — passed;
- `node tests/mobile-core.test.js` — 20 assertions passed;
- `AndroidManifest.xml` — valid XML;
- оба workflow YAML — синтаксически разобраны;
- Python-скрипты интеграции — AST syntax passed;
- Android GTOpen memory-limit patch — проверен на fixture.

Ранее в версии 0.6.0 также проверялись импорт 165 раздач / 254 решений Hero и parity spot_key 254/254.

Не проверено в этой среде: Rust/Cargo host build, Android ARM64 Rust/NDK build, TexasSolver C++/CMake NDK build, APK assembly, запуск на физическом Android-устройстве, производительность и корректность расчётов на реальных игровых сценариях. Для этого добавлены обязательные CI build steps и APK payload verification; до их успешного завершения сборка не считается подтверждённой.

## Структура

- `app/src/main/java/.../MainActivity.java` — Android-оболочка, SAF импорт/экспорт, загрузка диапазонов.
- `app/src/main/assets/` — локальный интерфейс и аналитическое ядро.
- `tests/` — Node.js smoke tests для аналитического ядра.
- `scripts/` — интеграция и проверка TexasSolver; `rust/` — JNI-обёртка GTOpen; `.github/workflows/` — облачная сборка обоих native engines и APK.
