use jni::objects::{JClass, JString};
use jni::sys::{jint, jstring};
use jni::JNIEnv;
use rayon::ThreadPoolBuilder;
use serde_json::{json, Value};
use solver::preflop::{
    equity::{class_label, EquityTable, NUM_CLASSES},
    estimate_tree, PreflopConfig, PreflopSolver,
};
use std::panic::{catch_unwind, AssertUnwindSafe};
use std::ptr;
use std::sync::{Arc, Mutex, Once, OnceLock};

static SOLVER: OnceLock<Mutex<Option<PreflopSolver>>> = OnceLock::new();
static RAYON_INIT: Once = Once::new();

fn solver_cell() -> &'static Mutex<Option<PreflopSolver>> {
    SOLVER.get_or_init(|| Mutex::new(None))
}

fn init_worker_pool() {
    RAYON_INIT.call_once(|| {
        let cores = std::thread::available_parallelism()
            .map(|n| n.get())
            .unwrap_or(2)
            .clamp(1, 4);
        let _ = ThreadPoolBuilder::new().num_threads(cores).build_global();
    });
}

fn error_value(message: impl Into<String>) -> Value {
    json!({"ok": false, "error": message.into()})
}

fn render_node(solver: &PreflopSolver, path: &[usize]) -> Result<Value, String> {
    let view = solver.node_view(path)?;
    let action_evs = if view.kind == "action" && view.strategy_note.is_none() {
        Some(solver.diagnostic_action_evs(path, false)?)
    } else {
        None
    };

    let mut hands = Vec::with_capacity(NUM_CLASSES);
    if view.kind == "action" {
        for h in 0..NUM_CLASSES {
            let mut actions = Vec::with_capacity(view.actions.len());
            for (a, action) in view.actions.iter().enumerate() {
                let frequency = view.strategy.as_ref().and_then(|sigma| {
                    sigma.get(a * NUM_CLASSES + h).copied().map(|v| v as f64)
                });
                let ev_bb = action_evs.as_ref().and_then(|values| {
                    values.get(a).and_then(|row| row.get(h)).copied()
                });
                actions.push(json!({
                    "label": action.label,
                    "frequency": frequency,
                    "ev_bb": ev_bb
                }));
            }
            hands.push(json!({"hand": class_label(h), "actions": actions}));
        }
    }

    let view_json = serde_json::to_value(&view).map_err(|e| e.to_string())?;
    Ok(json!({
        "ok": true,
        "engine": "GTOpen",
        "iteration": solver.iteration,
        "path": path,
        "view": view_json,
        "hands": hands,
        "ev_units": "bb relative to folding at this node",
        "model_note": "Preflop continuation is an approximation, not a full postflop solve."
    }))
}

fn solve(config_json: &str, iterations: u32, path_json: &str, equity_path: &str) -> Value {
    init_worker_pool();
    let outcome = catch_unwind(AssertUnwindSafe(|| -> Result<Value, String> {
        let config: PreflopConfig =
            serde_json::from_str(config_json).map_err(|e| format!("Invalid config: {e}"))?;
        let estimate = estimate_tree(&config)?;
        let equity = Arc::new(EquityTable::load_or_build(equity_path, 20_000));
        let mut solver = PreflopSolver::new(config, equity)?;
        for _ in 0..iterations.clamp(1, 500_000) {
            solver.iterate();
        }
        let path: Vec<usize> =
            serde_json::from_str(path_json).map_err(|e| format!("Invalid action path: {e}"))?;
        let mut result = render_node(&solver, &path)?;
        result["estimated_tree"] = serde_json::to_value(estimate).unwrap_or(Value::Null);
        *solver_cell().lock().unwrap_or_else(|e| e.into_inner()) = Some(solver);
        Ok(result)
    }));
    match outcome {
        Ok(Ok(v)) => v,
        Ok(Err(e)) => error_value(e),
        Err(_) => error_value("Native solver panicked; the game tree may exceed this device's resources."),
    }
}

fn query(path_json: &str) -> Value {
    let outcome = catch_unwind(AssertUnwindSafe(|| -> Result<Value, String> {
        let path: Vec<usize> =
            serde_json::from_str(path_json).map_err(|e| format!("Invalid action path: {e}"))?;
        let guard = solver_cell().lock().unwrap_or_else(|e| e.into_inner());
        let solver = guard.as_ref().ok_or_else(|| "No preflop game is loaded".to_string())?;
        render_node(solver, &path)
    }));
    match outcome {
        Ok(Ok(v)) => v,
        Ok(Err(e)) => error_value(e),
        Err(_) => error_value("Native node query failed."),
    }
}

fn continue_solve(iterations: u32, path_json: &str) -> Value {
    let outcome = catch_unwind(AssertUnwindSafe(|| -> Result<Value, String> {
        init_worker_pool();
        let path: Vec<usize> =
            serde_json::from_str(path_json).map_err(|e| format!("Invalid action path: {e}"))?;
        let mut guard = solver_cell().lock().unwrap_or_else(|e| e.into_inner());
        let solver = guard.as_mut().ok_or_else(|| "No preflop game is loaded".to_string())?;
        for _ in 0..iterations.clamp(1, 100_000) {
            solver.iterate();
        }
        render_node(solver, &path)
    }));
    match outcome {
        Ok(Ok(v)) => v,
        Ok(Err(e)) => error_value(e),
        Err(_) => error_value("Native continuation solve failed."),
    }
}

fn read_string(env: &mut JNIEnv, value: JString) -> Result<String, String> {
    env.get_string(&value)
        .map(|s| s.into())
        .map_err(|e| format!("JNI string error: {e}"))
}

fn write_string(env: &mut JNIEnv, value: Value) -> jstring {
    let text = value.to_string();
    match env.new_string(text) {
        Ok(s) => s.into_raw(),
        Err(_) => ptr::null_mut(),
    }
}

#[no_mangle]
pub extern "system" fn Java_com_adaptivepoker_study_MainActivity_nativeSolvePreflop(
    mut env: JNIEnv,
    _class: JClass,
    config_json: JString,
    iterations: jint,
    path_json: JString,
    equity_path: JString,
) -> jstring {
    let parsed = (|| -> Result<Value, String> {
        let config = read_string(&mut env, config_json)?;
        let path = read_string(&mut env, path_json)?;
        let equity = read_string(&mut env, equity_path)?;
        Ok(solve(&config, iterations.max(1) as u32, &path, &equity))
    })()
    .unwrap_or_else(error_value);
    write_string(&mut env, parsed)
}

#[no_mangle]
pub extern "system" fn Java_com_adaptivepoker_study_MainActivity_nativeGetPreflopNode(
    mut env: JNIEnv,
    _class: JClass,
    path_json: JString,
) -> jstring {
    let parsed = read_string(&mut env, path_json)
        .map(|path| query(&path))
        .unwrap_or_else(error_value);
    write_string(&mut env, parsed)
}

#[no_mangle]
pub extern "system" fn Java_com_adaptivepoker_study_MainActivity_nativeContinuePreflop(
    mut env: JNIEnv,
    _class: JClass,
    iterations: jint,
    path_json: JString,
) -> jstring {
    let parsed = read_string(&mut env, path_json)
        .map(|path| continue_solve(iterations.max(1) as u32, &path))
        .unwrap_or_else(error_value);
    write_string(&mut env, parsed)
}


#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn spin_preflop_root_exposes_169_frequencies_and_action_evs() {
        let config: PreflopConfig = serde_json::from_str(
            r#"{
                "positions":["BTN","SB","BB"],
                "stack":10.0,
                "posts":[0.0,0.5,1.0],
                "ante":0.0,
                "limp":false,
                "open_raises":[2.5],
                "raise_mults":[3.0],
                "max_raises":2,
                "add_allin":true,
                "allin_threshold":0.85,
                "rake_pct":0.0,
                "rake_cap":0.0,
                "no_flop_no_drop":true,
                "realization":"static"
            }"#,
        )
        .unwrap();

        let equity = Arc::new(EquityTable::build(10));
        let mut game = PreflopSolver::new(config, equity).unwrap();
        for _ in 0..10 {
            game.iterate();
        }

        let view = game.node_view(&[]).unwrap();
        assert_eq!(view.kind, "action");
        assert!(view.strategy_note.is_none());
        let strategy = view.strategy.as_ref().expect("solved root strategy");
        assert_eq!(strategy.len(), view.actions.len() * NUM_CLASSES);

        let evs = game.diagnostic_action_evs(&[], false).unwrap();
        assert_eq!(evs.len(), view.actions.len());
        assert!(evs.iter().all(|row| row.len() == NUM_CLASSES));
        assert!(strategy.iter().all(|v| v.is_finite() && *v >= 0.0 && *v <= 1.00001));
        assert!(evs.iter().flatten().all(|v| v.is_finite()));
    }
}
