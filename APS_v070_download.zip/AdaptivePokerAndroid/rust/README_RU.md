# Android native bridge для GTOpen

Это JNI-обёртка над `solver::preflop`. Сборочный workflow помещает исходный crate GTOpen в `rust/vendor/solver` из закреплённого commit SHA.

- Используется CPU-сборка без CUDA и без GTOpen server/browser.
- Результаты частот берутся из `PreflopSolver::node_view`.
- Action EV берутся из `diagnostic_action_evs(..., false)` и возвращаются в BB относительно фолда в текущем узле.
- Продолжение дерева моделируется GTOpen preflop continuation model; это не полноценный постфлоп solve.
- Equity cache копируется из GTOpen в Android assets и переносится в app-private storage при первом запуске.
