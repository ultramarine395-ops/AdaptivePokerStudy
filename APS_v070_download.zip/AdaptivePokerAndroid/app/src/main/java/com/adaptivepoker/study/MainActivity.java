package com.adaptivepoker.study;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.JsResult;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

public class MainActivity extends Activity {
    private static final String APP_ASSET_BASE = "https://appassets.androidplatform.net/assets/";
    private static final int REQ_OPEN = 7101;
    private static final int REQ_SAVE = 7102;
    private static final long MAX_IMPORT_BYTES = 50L * 1024L * 1024L;
    private static final String RANGE_BASE = "https://raw.githubusercontent.com/jensbaagaard/poker-practice/main/data/openSourcePokerData/";
    private static final String[] RANGE_FILES = {
            "MTT_5_GTO.json", "MTT_10_GTO.json", "MTT_20_GTO.json", "MTT_40_GTO.json", "MTT_100_GTO.json"
    };

    private WebView webView;
    private String pendingExportName = "adaptive_poker_report.json";
    private String pendingExportMime = "application/json";
    private byte[] pendingExportBytes = new byte[0];

    private static final boolean PREFLOP_NATIVE_AVAILABLE;
    static {
        boolean loaded;
        try {
            System.loadLibrary("aps_preflop_android");
            loaded = true;
        } catch (Throwable ignored) {
            loaded = false;
        }
        PREFLOP_NATIVE_AVAILABLE = loaded;
    }

    private static native String nativeSolvePreflop(String configJson, int iterations, String pathJson, String equityPath);
    private static native String nativeGetPreflopNode(String pathJson);
    private static native String nativeContinuePreflop(int iterations, String pathJson);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(android.graphics.Color.rgb(16, 23, 34));
        getWindow().setNavigationBarColor(android.graphics.Color.rgb(16, 23, 34));
        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onJsConfirm(WebView view, String url, String message, JsResult result) {
                new android.app.AlertDialog.Builder(MainActivity.this)
                        .setMessage(message)
                        .setNegativeButton("Отмена", (dialog, which) -> result.cancel())
                        .setPositiveButton("Удалить", (dialog, which) -> result.confirm())
                        .setOnCancelListener(dialog -> result.cancel())
                        .show();
                return true;
            }
        });
        webView.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return url == null || !url.startsWith(APP_ASSET_BASE);
            }
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if ("appassets.androidplatform.net".equals(uri.getHost()) && uri.getPath() != null && uri.getPath().startsWith("/assets/")) {
                    String asset = uri.getPath().substring("/assets/".length());
                    try {
                        String mime = asset.endsWith(".html") ? "text/html" : asset.endsWith(".js") ? "application/javascript" : asset.endsWith(".css") ? "text/css" : "application/octet-stream";
                        return new WebResourceResponse(mime, "UTF-8", getAssets().open(asset));
                    } catch (Exception ignored) {
                        return new WebResourceResponse("text/plain", "UTF-8", new java.io.ByteArrayInputStream(new byte[0]));
                    }
                }
                // No external WebView navigation or remote scripts/resources.
                return new WebResourceResponse("text/plain", "UTF-8", new java.io.ByteArrayInputStream(new byte[0]));
            }
        });
        webView.loadUrl(APP_ASSET_BASE + "index.html");
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    private String queryName(Uri uri) {
        String name = "import";
        try (Cursor c = getContentResolver().query(uri, null, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                int i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (i >= 0) name = c.getString(i);
            }
        } catch (Exception ignored) { }
        return name;
    }

    private byte[] readAll(InputStream in, long maxBytes) throws Exception {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        long total = 0;
        int n;
        while ((n = in.read(buf)) != -1) {
            total += n;
            if (total > maxBytes) throw new IllegalArgumentException("File exceeds import limit");
            out.write(buf, 0, n);
        }
        return out.toByteArray();
    }

    private JSONArray makeEntries(String name, byte[] bytes) throws Exception {
        JSONArray entries = new JSONArray();
        if (name.toLowerCase(Locale.ROOT).endsWith(".zip")) {
            long total = 0;
            try (ZipInputStream zin = new ZipInputStream(new java.io.ByteArrayInputStream(bytes))) {
                ZipEntry entry;
                while ((entry = zin.getNextEntry()) != null) {
                    if (entry.isDirectory()) continue;
                    String n = entry.getName();
                    String lower = n.toLowerCase(Locale.ROOT);
                    if (n.startsWith("__MACOSX/") || n.contains("../")) continue;
                    if (!(lower.endsWith(".txt") || lower.endsWith(".json") || lower.endsWith(".csv"))) continue;
                    byte[] payload = readAll(zin, MAX_IMPORT_BYTES - total);
                    total += payload.length;
                    JSONObject item = new JSONObject();
                    item.put("name", n.substring(n.lastIndexOf('/') + 1));
                    item.put("base64", android.util.Base64.encodeToString(payload, android.util.Base64.NO_WRAP));
                    entries.put(item);
                    if (total > MAX_IMPORT_BYTES) throw new IllegalArgumentException("Archive expands beyond import limit");
                }
            }
        } else {
            JSONObject item = new JSONObject();
            item.put("name", name);
            item.put("base64", android.util.Base64.encodeToString(bytes, android.util.Base64.NO_WRAP));
            entries.put(item);
        }
        return entries;
    }

    private String ensurePreflopEquityCache() throws Exception {
        File target = new File(getFilesDir(), "preflop_eq169.bin");
        if (!target.exists() || target.length() != 114248L) {
            try (InputStream in = getAssets().open("preflop_eq169.bin");
                 FileOutputStream out = new FileOutputStream(target, false)) {
                byte[] buffer = new byte[8192];
                int n;
                while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
                out.flush();
            }
        }
        if (target.length() != 114248L) throw new IllegalStateException("Preflop equity cache is missing or invalid");
        return target.getAbsolutePath();
    }

    private void js(String expression) {
        runOnUiThread(() -> {
            if (webView != null) webView.evaluateJavascript(expression, null);
        });
    }

    private class AndroidBridge {
        @JavascriptInterface public void pickFile() {
            runOnUiThread(() -> {
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("*/*");
                intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{
                        "text/plain", "application/zip", "application/json", "text/csv", "application/octet-stream"
                });
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                startActivityForResult(intent, REQ_OPEN);
            });
        }

        @JavascriptInterface public void downloadRanges() {
            new Thread(() -> {
                try {
                    JSONArray files = new JSONArray();
                    for (String file : RANGE_FILES) {
                        URL url = new URL(RANGE_BASE + file);
                        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                        conn.setConnectTimeout(15000);
                        conn.setReadTimeout(30000);
                        conn.setRequestProperty("User-Agent", "AdaptivePokerStudy/0.6 Android");
                        conn.setInstanceFollowRedirects(true);
                        try {
                            int code = conn.getResponseCode();
                            if (code < 200 || code >= 300) throw new IllegalStateException("HTTP " + code + " for " + file);
                            byte[] payload;
                            try (InputStream in = conn.getInputStream()) { payload = readAll(in, 15L * 1024L * 1024L); }
                            // Validate that the upstream file is a JSON object before saving it.
                            new JSONObject(new String(payload, StandardCharsets.UTF_8));
                            java.io.File dir = new java.io.File(getFilesDir(), "mtt_ranges");
                            if (!dir.exists() && !dir.mkdirs()) throw new IllegalStateException("Cannot create ranges folder");
                            try (OutputStream out = new java.io.FileOutputStream(new java.io.File(dir, file))) { out.write(payload); }
                            JSONObject item = new JSONObject();
                            item.put("name", file);
                            item.put("base64", android.util.Base64.encodeToString(payload, android.util.Base64.NO_WRAP));
                            files.put(item);
                        } finally { conn.disconnect(); }
                    }
                    js("window.onNativeRangesDownloaded(" + JSONObject.quote(files.toString()) + ")");
                } catch (Exception e) {
                    js("window.onNativeRangeDownloadError(" + JSONObject.quote(e.getMessage() == null ? "Download failed" : e.getMessage()) + ")");
                }
            }, "range-download").start();
        }

        @JavascriptInterface public void exportFile(String fileName, String mimeType, String base64) {
            try {
                pendingExportName = (fileName == null || fileName.trim().isEmpty()) ? "poker-study-report.json" : fileName;
                pendingExportMime = (mimeType == null || mimeType.trim().isEmpty()) ? "application/octet-stream" : mimeType;
                pendingExportBytes = android.util.Base64.decode(base64, android.util.Base64.DEFAULT);
                runOnUiThread(() -> {
                    Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType(pendingExportMime);
                    intent.putExtra(Intent.EXTRA_TITLE, pendingExportName);
                    startActivityForResult(intent, REQ_SAVE);
                });
            } catch (Exception e) {
                js("window.onNativeExportError(" + JSONObject.quote(e.getMessage() == null ? "Export failed" : e.getMessage()) + ")");
            }
        }

        @JavascriptInterface public boolean isPreflopAvailable() {
            return PREFLOP_NATIVE_AVAILABLE;
        }

        @JavascriptInterface public void solvePreflop(String configJson, String pathJson, int iterations) {
            if (!PREFLOP_NATIVE_AVAILABLE) {
                js("window.onNativePreflopError(" + JSONObject.quote("Native GTOpen module is not present in this APK") + ")");
                return;
            }
            new Thread(() -> {
                try {
                    String equityPath = ensurePreflopEquityCache();
                    String result = nativeSolvePreflop(configJson, iterations, pathJson, equityPath);
                    js("window.onNativePreflopResult(" + JSONObject.quote(result) + ")");
                } catch (Throwable e) {
                    String message = e.getMessage() == null ? "Preflop solve failed" : e.getMessage();
                    js("window.onNativePreflopError(" + JSONObject.quote(message) + ")");
                }
            }, "preflop-solve").start();
        }

        @JavascriptInterface public void getPreflopNode(String pathJson) {
            new Thread(() -> {
                try {
                    String result = nativeGetPreflopNode(pathJson);
                    js("window.onNativePreflopResult(" + JSONObject.quote(result) + ")");
                } catch (Throwable e) {
                    String message = e.getMessage() == null ? "Node query failed" : e.getMessage();
                    js("window.onNativePreflopError(" + JSONObject.quote(message) + ")");
                }
            }, "preflop-query").start();
        }

        @JavascriptInterface public void continuePreflop(int iterations, String pathJson) {
            new Thread(() -> {
                try {
                    String result = nativeContinuePreflop(iterations, pathJson);
                    js("window.onNativePreflopResult(" + JSONObject.quote(result) + ")");
                } catch (Throwable e) {
                    String message = e.getMessage() == null ? "Continue solve failed" : e.getMessage();
                    js("window.onNativePreflopError(" + JSONObject.quote(message) + ")");
                }
            }, "preflop-continue").start();
        }

        @JavascriptInterface public void toast(String message) {
            runOnUiThread(() -> Toast.makeText(MainActivity.this, message, Toast.LENGTH_SHORT).show());
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null) return;
        Uri uri = data.getData();
        if (uri == null) return;
        if (requestCode == REQ_OPEN) {
            new Thread(() -> {
                try {
                    String name = queryName(uri);
                    byte[] bytes;
                    try (InputStream in = getContentResolver().openInputStream(uri)) {
                        if (in == null) throw new IllegalStateException("Cannot open selected file");
                        bytes = readAll(in, MAX_IMPORT_BYTES);
                    }
                    JSONArray entries = makeEntries(name, bytes);
                    if (entries.length() == 0) throw new IllegalArgumentException("No TXT/JSON/CSV files found in selection");
                    js("window.onNativeImport(" + JSONObject.quote(name) + "," + JSONObject.quote(entries.toString()) + ")");
                } catch (Exception e) {
                    js("window.onNativeImportError(" + JSONObject.quote(e.getMessage() == null ? "Import failed" : e.getMessage()) + ")");
                }
            }, "file-import").start();
        } else if (requestCode == REQ_SAVE) {
            new Thread(() -> {
                try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                    if (out == null) throw new IllegalStateException("Cannot create destination file");
                    out.write(pendingExportBytes);
                    js("window.onNativeExportSuccess(" + JSONObject.quote(pendingExportName) + ")");
                } catch (Exception e) {
                    js("window.onNativeExportError(" + JSONObject.quote(e.getMessage() == null ? "Export failed" : e.getMessage()) + ")");
                }
            }, "file-export").start();
        }
    }
}
