#!/usr/bin/env python3
"""Verify that an APK contains the real TexasSolver ARM64 native payload."""
from __future__ import annotations
import gzip
import io
import struct
import sys
import zipfile


def fail(message: str) -> None:
    raise SystemExit("NATIVE APK VERIFY FAILED: " + message)


def main() -> None:
    if len(sys.argv) != 2:
        fail("usage: python3 verify_native_apk.py app-debug.apk")
    apk_path = sys.argv[1]
    try:
        archive = zipfile.ZipFile(apk_path)
    except Exception as exc:
        fail(f"cannot open APK: {exc}")

    names = set(archive.namelist())
    native_path = "lib/arm64-v8a/libtexassolver_jni.so"
    preflop_native_path = "lib/arm64-v8a/libaps_preflop_android.so"
    asset_path = "assets/solver/card5_dic_sorted.txt.gz"
    equity_asset_path = "assets/preflop_eq169.bin"
    for required in (native_path, preflop_native_path, asset_path, equity_asset_path):
        if required not in names:
            fail(f"missing {required}")

    native = archive.read(native_path)
    if len(native) < 200_000:
        fail(f"native library is suspiciously small ({len(native)} bytes)")
    if native[:4] != b"\x7fELF":
        fail("native library is not an ELF object")
    if native[4] != 2:
        fail("native library is not ELF64")
    if native[5] != 1:
        fail("native library is not little-endian")
    machine = struct.unpack_from("<H", native, 18)[0]
    if machine != 183:
        fail(f"expected AArch64 ELF machine 183, found {machine}")
    for marker in (b"TexasSolver C++ engine", b"<<<START SOLVING>>>", b"discounted_cfr"):
        if marker not in native:
            fail(f"native library does not contain engine marker {marker!r}")

    preflop_native = archive.read(preflop_native_path)
    if len(preflop_native) < 100_000:
        fail(f"GTOpen native library is suspiciously small ({len(preflop_native)} bytes)")
    if preflop_native[:4] != b"\x7fELF" or preflop_native[4] != 2 or preflop_native[5] != 1:
        fail("GTOpen native library is not a little-endian ELF64 object")
    preflop_machine = struct.unpack_from("<H", preflop_native, 18)[0]
    if preflop_machine != 183:
        fail(f"expected GTOpen AArch64 ELF machine 183, found {preflop_machine}")
    equity_asset = archive.read(equity_asset_path)
    if len(equity_asset) != 114248:
        fail(f"preflop equity cache has unexpected size ({len(equity_asset)} bytes)")

    # Validate the complete gzip stream and the expected uncompressed size.
    expanded = 0
    try:
        with archive.open(asset_path) as apk_stream:
            with gzip.GzipFile(fileobj=apk_stream, mode="rb") as gz:
                while True:
                    chunk = gz.read(1024 * 1024)
                    if not chunk:
                        break
                    expanded += len(chunk)
    except Exception as exc:
        fail(f"evaluator gzip is corrupt: {exc}")
    if expanded < 50_000_000:
        fail(f"evaluator expanded to only {expanded} bytes")

    licenses = [n for n in names if n.startswith("assets/licenses/")]
    if not any("TexasSolver-LICENSE" in n for n in licenses):
        fail("TexasSolver license notice is missing")
    dex_names = [n for n in names if n.startswith("classes") and n.endswith(".dex")]
    dex = b"".join(archive.read(n) for n in dex_names)
    if b"TexasSolverBridge" not in dex or b"nativeRun" not in dex:
        fail("Java JNI bridge class is missing from DEX")
    if b"nativeSolvePreflop" not in dex or b"isPreflopAvailable" not in dex:
        fail("GTOpen JNI methods are missing from MainActivity DEX")

    print("NATIVE APK VERIFY OK")
    print(f"APK: {apk_path}")
    print(f"TexasSolver ARM64 JNI library: {len(native):,} bytes")
    print(f"GTOpen ARM64 JNI library: {len(preflop_native):,} bytes")
    print(f"Evaluator: {expanded:,} uncompressed bytes")
    print(f"License notices: {len(licenses)}")


if __name__ == "__main__":
    main()
