#!/usr/bin/env python3
"""Apply conservative arena/node ceilings to the pinned GTOpen Android build."""
from pathlib import Path
import sys

path = Path(sys.argv[1] if len(sys.argv) > 1 else "rust/vendor/solver/src/preflop/mod.rs")
source = path.read_text(encoding="utf-8")
old_mem = "avail_mem_mb().map(|a| a * 0.40).unwrap_or(2000.0)"
new_mem = "avail_mem_mb().map(|a| (a * 0.40).min(384.0)).unwrap_or(384.0)"
old_nodes = "(limit_arena_mb() * 830.0) as u64"
new_nodes = "((limit_arena_mb() * 830.0) as u64).min(300_000)"
if source.count(old_mem) != 1:
    raise SystemExit("Expected exactly one GTOpen arena-limit expression; upstream source changed.")
if source.count(old_nodes) != 1:
    raise SystemExit("Expected exactly one GTOpen node-limit expression; upstream source changed.")
source = source.replace(old_mem, new_mem).replace(old_nodes, new_nodes)
path.write_text(source, encoding="utf-8")
print("GTOpen Android limits applied: max 384 MB arenas, max 300,000 nodes.")
